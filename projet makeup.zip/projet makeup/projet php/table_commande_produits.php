<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: connexion.php?error=auth_required");
    exit();
}

$id_commande = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id_commande) {
    header("Location: table_commandes.php");
    exit();
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données. Veuillez réessayer plus tard.");
}

// 1. Récupérer les informations de la commande et du client
$stmt_commande = $pdo->prepare("
    SELECT 
        c.id_commande, c.date_commande, c.total, c.statut, 
        c.adresse_livraison, c.ville, c.code_postal,
        cl.nom, cl.prenom, cl.email, cl.telephone
    FROM 
        commandes c
    JOIN 
        client cl ON c.id_client = cl.id
    WHERE 
        c.id_commande = ?
");
$stmt_commande->execute([$id_commande]);
$commande = $stmt_commande->fetch(PDO::FETCH_ASSOC);

// Si la commande n'existe pas, rediriger
if (!$commande) {
    header("Location: table_commandes.php?error=not_found");
    exit();
}

// 2. Récupérer les produits de la commande
$stmt_produits = $pdo->prepare("
    SELECT 
        p.nom, p.image,
        cp.quantite, cp.prix_unitaire
    FROM 
        commande_produits cp
    JOIN 
        produit p ON cp.id_produit = p.id
    WHERE 
        cp.id_commande = ?
");
$stmt_produits->execute([$id_commande]);
$produits = $stmt_produits->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails Commande #<?php echo htmlspecialchars($commande['id_commande']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: { '50': '#f0f4ff', '100': '#dde6ff', '200': '#c2d3ff', '300': '#9cb6ff', '400': '#758dff', '500': '#4f61ff', '600': '#2f3af5', '700': '#222ad8', '800': '#2128ae', '900': '#212989', '950': '#131652' }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow { box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); }
    </style>
</head>
<body class="bg-beige">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-file-invoice-dollar mr-3 text-navy-600"></i>
                Détails de la Commande #<?php echo htmlspecialchars($commande['id_commande']); ?>
            </h1>
            <a href="table_commandes.php" class="bg-navy-700 hover:bg-navy-800 text-white px-4 py-2 rounded-lg transition duration-200 flex items-center">
                <i class="fas fa-arrow-left mr-2"></i> Retour aux commandes
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Colonne principale : produits -->
            <div class="lg:col-span-2 bg-white rounded-lg custom-shadow overflow-hidden">
                <div class="px-6 py-4 border-b bg-navy-700 text-white">
                    <h2 class="text-lg font-semibold"><i class="fas fa-boxes mr-2"></i>Produits Commandés</h2>
                </div>
                <table class="min-w-full">
                    <thead class="bg-navy-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">Produit</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-navy-700 uppercase tracking-wider">Prix Unitaire</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-navy-700 uppercase tracking-wider">Quantité</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-navy-700 uppercase tracking-wider">Sous-total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($produits as $produit): ?>
                        <tr>
                            <td class="px-6 py-4 flex items-center">
                                <img src="uploads/<?php echo htmlspecialchars($produit['image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($produit['nom']); ?>" class="h-12 w-12 object-cover rounded-md mr-4">
                                <span class="font-medium text-gray-800"><?php echo htmlspecialchars($produit['nom']); ?></span>
                            </td>
                            <td class="px-6 py-4 text-right text-sm text-gray-600"><?php echo number_format($produit['prix_unitaire'], 2, ',', ' '); ?> MAD</td>
                            <td class="px-6 py-4 text-center text-sm text-gray-600"><?php echo htmlspecialchars($produit['quantite']); ?></td>
                            <td class="px-6 py-4 text-right text-sm font-semibold text-gray-800"><?php echo number_format($produit['prix_unitaire'] * $produit['quantite'], 2, ',', ' '); ?> MAD</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="bg-gray-50">
                        <tr>
                            <td colspan="3" class="px-6 py-4 text-right font-bold text-gray-700 text-lg">Total Général</td>
                            <td class="px-6 py-4 text-right font-bold text-navy-800 text-lg"><?php echo number_format($commande['total'], 2, ',', ' '); ?> MAD</td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Colonne latérale : infos client et livraison -->
            <div class="space-y-8">
                <div class="bg-white rounded-lg custom-shadow p-6">
                    <h3 class="text-lg font-semibold text-navy-800 border-b pb-3 mb-4"><i class="fas fa-user-circle mr-2"></i>Informations du Client</h3>
                    <p><strong>Nom:</strong> <?php echo htmlspecialchars($commande['prenom'] . ' ' . $commande['nom']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($commande['email']); ?></p>
                    <p><strong>Téléphone:</strong> <?php echo htmlspecialchars($commande['telephone']); ?></p>
                </div>
                <div class="bg-white rounded-lg custom-shadow p-6">
                    <h3 class="text-lg font-semibold text-navy-800 border-b pb-3 mb-4"><i class="fas fa-shipping-fast mr-2"></i>Adresse de Livraison</h3>
                    <p><?php echo htmlspecialchars($commande['adresse_livraison']); ?></p>
                    <p><?php echo htmlspecialchars($commande['code_postal']) . ' ' . htmlspecialchars($commande['ville']); ?></p>
                </div>
                <div class="bg-white rounded-lg custom-shadow p-6">
                    <h3 class="text-lg font-semibold text-navy-800 border-b pb-3 mb-4"><i class="fas fa-info-circle mr-2"></i>Statut de la Commande</h3>
                    <p><strong>Date:</strong> <?php echo htmlspecialchars(date('d/m/Y à H:i', strtotime($commande['date_commande']))); ?></p>
                    <p><strong>Statut:</strong> <span class="px-2 py-1 text-sm font-semibold rounded-full bg-yellow-100 text-yellow-800"><?php echo htmlspecialchars($commande['statut']); ?></span></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
