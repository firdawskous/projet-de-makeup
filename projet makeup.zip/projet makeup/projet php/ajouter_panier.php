<?php
session_start();

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    // Dans une application réelle, il serait préférable de logger cette erreur
    // et d'afficher un message d'erreur générique à l'utilisateur.
    die("Erreur de connexion à la base de données. Impossible d'ajouter le produit au panier.");
}
 
// Vérifier si le formulaire a été soumis et si l'ID du produit est présent
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_produit'])) {
    $id_produit = $_POST['id_produit'];
    $quantite = isset($_POST['quantite']) ? (int)$_POST['quantite'] : 1;

    // Valider la quantité (doit être supérieure à 0)
    if ($quantite <= 0) {
        // Rediriger si la quantité est invalide (on pourrait aussi afficher un message)
        header('Location: produits_accueil.php');
        exit();
    }

    // Vérifier si le produit existe dans la base de données et est disponible
    try {
        $stmt = $pdo->prepare("SELECT id FROM produit WHERE id = ? AND disponibilite != 'out-of-stock'");
        $stmt->execute([$id_produit]);

        if ($stmt->fetch()) {
            // Le produit existe et est disponible, on peut l'ajouter au panier

            // Initialiser le panier dans la session s'il n'existe pas encore
            if (!isset($_SESSION['panier'])) {
                $_SESSION['panier'] = [];
            }

            // Ajouter le produit au panier ou mettre à jour la quantité si déjà présent
            $_SESSION['panier'][$id_produit] = ($_SESSION['panier'][$id_produit] ?? 0) + $quantite;
        }
    } catch (PDOException $e) {
        // En cas d'erreur de base de données, on pourrait logger l'erreur.
        // Pour l'instant, on ne fait rien et la redirection finale s'occupera de la suite.
        // die("Erreur: " . $e->getMessage()); // Décommenter pour le débogage
    }
}

// Rediriger l'utilisateur vers la page d'où il vient (ou une page par défaut)
$redirect_url = $_SERVER['HTTP_REFERER'] ?? 'produits_accueil.php';
header('Location: ' . $redirect_url);
exit();
