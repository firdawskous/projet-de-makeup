<?php
session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_inscription'])) {

    $nom = trim(htmlspecialchars($_POST['nom'] ?? '', ENT_QUOTES, 'UTF-8'));
    $prenom = trim(htmlspecialchars($_POST['prenom'] ?? '', ENT_QUOTES, 'UTF-8'));
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $telephone = trim(htmlspecialchars($_POST['telephone'] ?? '', ENT_QUOTES, 'UTF-8')); // Peut nécessiter une validation plus spécifique
    $password_plain = $_POST['password'];
    $confirm_password_plain = $_POST['confirm_password'];
    $terms_accepted = isset($_POST['terms']);

    $errors = [];
    if (empty($nom)) $errors[] = "Le nom est requis.";
    if (empty($prenom)) $errors[] = "Le prénom est requis.";
    if (empty($email)) {
        $errors[] = "L'adresse email est requise.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format d'adresse email invalide.";
    }
    if (empty($telephone)) $errors[] = "Le numéro de téléphone est requis."; // Adaptez si optionnel
    
    if (empty($password_plain)) {
        $errors[] = "Le mot de passe est requis.";
    } elseif (strlen($password_plain) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($password_plain !== $confirm_password_plain) {
        $errors[] = "Les mots de passe ne correspondent pas.";
    }

    if (!$terms_accepted) {
        $errors[] = "Vous devez accepter les Conditions Générales d'Utilisation.";
    }

    if (!empty($errors)) {
        $_SESSION['inscription_errors'] = $errors;
        $_SESSION['form_data'] = $_POST; 
        header("Location: inscription.php");
        exit();
    }

    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    try {
        $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        $stmt_check = $pdo->prepare("SELECT id FROM client WHERE email = :email");
        $stmt_check->bindParam(':email', $email);
        $stmt_check->execute();
        if ($stmt_check->fetch()) {
            $_SESSION['inscription_errors'] = ["Cette adresse email est déjà utilisée."];
            $_SESSION['form_data'] = $_POST;
            header("Location: inscription.php");
            exit();
        }

        $sql = "INSERT INTO client (nom, prenom, email, telephone, password) VALUES (:nom, :prenom, :email, :telephone, :password)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':telephone', $telephone);
        $stmt->bindParam(':password', $password_hashed);
        
        $stmt->execute();

        header("Location: connexion.php?status=client_registered"); 
        exit();

    } catch (PDOException $e) {
        $_SESSION['inscription_errors'] = ["Erreur lors de l'inscription : " . $e->getMessage()]; 
        $_SESSION['form_data'] = $_POST;
        header("Location: inscription.php");
        exit();
    }
} else {
    header("Location: inscription.php");
    exit();
}
?>