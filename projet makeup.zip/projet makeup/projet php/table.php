<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: connexion.php?error=auth_required");
    exit();
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données. Veuillez réessayer plus tard.");
}

$stmt = $pdo->query("SELECT * FROM produit ORDER BY id DESC"); // Ajout de ORDER BY pour un affichage cohérent
?>
<!DOCTYPE html>

<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Tableau des Produits (Simple)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: {
                            '50': '#f0f4ff',
                            '100': '#dde6ff',
                            '200': '#c2d3ff',
                            '300': '#9cb6ff',
                            '400': '#758dff',
                            '500': '#4f61ff',
                            '600': '#2f3af5',
                            '700': '#222ad8',
                            '800': '#2128ae',
                            '900': '#212989',
                            '950': '#131652',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        .availability-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 0.375rem;
            font-size: 0.75rem;
            font-weight: 500;
            display: inline-flex; 
            align-items: center;
        }
    </style>
</head>

<body class="bg-beige">
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-8">
                    <a href="table.php" class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-navy-700 flex items-center justify-center text-white font-bold text-xl mr-2">A</div>
                        <span class="text-navy-800 font-semibold text-xl">Admin</span>
                    </a>
                    <div class="hidden md:flex space-x-6">
                        <a href="table.php" class="text-navy-700 font-semibold border-b-2 border-navy-700 pb-1">Produits</a>
                        <a href="table_client.php" class="text-gray-600 hover:text-navy-700 transition">Clients</a>
                        <a href="table_commandes.php" class="text-gray-600 hover:text-navy-700 transition">Commandes</a>
                        <a href="accueil.php" class="text-gray-600 hover:text-navy-700 transition" target="_blank" title="Ouvrir la page d'accueil dans un nouvel onglet">
                            Voir le site <i class="fas fa-external-link-alt text-xs ml-1"></i>
                        </a>
                    </div>
                </div>
                
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600 hidden sm:block">
                        Bienvenue, <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? $_SESSION['user_nom']); ?>!
                    </span>
                    <a href="profil.php" class="text-gray-600 hover:text-navy-700" title="Mon Profil">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-sm transition duration-200 flex items-center" title="Déconnexion">
                        <i class="fas fa-sign-out-alt md:mr-2"></i>
                        <span class="hidden md:inline">Déconnexion</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-table mr-3 text-navy-600"></i>
                Tableau des Produits
            </h1>
            <div class="flex items-center space-x-4">
                <a href="produit.php" class="bg-navy-700 hover:bg-navy-800 text-white px-4 py-2 rounded-lg transition duration-200 flex items-center">
                    <i class="fas fa-plus mr-2"></i> Ajouter un produit
                </a>
            </div>
        </div>

        
        <div class="bg-white rounded-lg custom-shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-navy-800 bg-navy-700">
                <h2 class="text-lg font-semibold text-white">
                    <i class="fas fa-boxes mr-2 text-navy-100"></i> Liste des produits
                </h2>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-navy-100">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-image mr-1"></i> Image
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-tag mr-1"></i> Nom
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-list-alt mr-1"></i> Type
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-barcode mr-1"></i> Code
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-copyright mr-1"></i> Marque
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-euro-sign mr-1"></i> Prix
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-store mr-1"></i> Disponibilité
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-cogs mr-1"></i> Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $dispo_text = htmlspecialchars($row['disponibilite']);
                            $dispo_class = 'bg-gray-100 text-gray-800'; 
                            $dispo_icon = 'fas fa-question-circle'; 

                            if (strtolower($dispo_text) === 'in-stock') {
                                $dispo_class = 'bg-green-100 text-green-800';
                                $dispo_icon = 'fas fa-check-circle';
                            } elseif (strtolower($dispo_text) === 'out-of-stock') {
                                $dispo_class = 'bg-red-100 text-red-800';
                                $dispo_icon = 'fas fa-times-circle';
                            } elseif (strtolower($dispo_text) === 'pre-order') {
                                $dispo_class = 'bg-blue-100 text-blue-800';
                                $dispo_icon = 'fas fa-clock';
                            }
                        ?>
                        <tr class="hover:bg-navy-50 transition duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if (!empty($row['image'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="Image <?php echo htmlspecialchars($row['nom']); ?>" class="h-16 w-16 object-cover rounded shadow-sm">
                                <?php else: ?>
                                    <span class="text-xs text-gray-400">Aucune image</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['nom']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['type']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['code']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['marque']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars(number_format((float)$row['prix'], 2, ',', ' ')); ?> MAD</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="availability-badge <?php echo $dispo_class; ?>">
                                    <i class="<?php echo $dispo_icon; ?> mr-1"></i> <?php echo $dispo_text; ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="update.php?id=<?php echo $row['id']; ?>" class="text-navy-600 hover:text-navy-900 mr-3" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="delete.php" method="POST" class="inline-block" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?');">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-900" title="Supprimer">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php
                        } 
                        if ($stmt->rowCount() === 0) {
                            echo '<tr><td colspan="8" class="px-6 py-4 text-center text-gray-500">Aucun produit trouvé.</td></tr>'; // Colspan est maintenant 8 (Image + 7 autres)
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>