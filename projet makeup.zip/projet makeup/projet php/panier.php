<?php
session_start();

// Connexion à la base de données
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

$panier = $_SESSION['panier'] ?? [];
$produits_panier = [];
$total_general = 0;

// Si le panier n'est pas vide, récupérer les informations des produits depuis la BDD
if (!empty($panier)) {
    // Créer une chaîne de placeholders (?,?,?) pour la clause IN
    $ids = array_keys($panier);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    try {
        $stmt = $pdo->prepare("SELECT id, nom, prix, image FROM produit WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $produits_resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Organiser les résultats par ID de produit pour un accès facile
        foreach ($produits_resultats as $produit) {
            $produits_panier[$produit['id']] = $produit;
        }
    } catch (PDOException $e) {
        die("Erreur lors de la récupération des produits du panier: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre Panier</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080',
                        'bleu-canard-fonce': '#006666',
                    }
                }
            }
        }
    </script>
    <style>
        .quantity-input {
            width: 60px;
        }
    </style>
</head>
<body class="bg-beige">

    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a href="accueil.php" class="text-bleu-canard font-semibold text-xl flex items-center">
                <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                firdaws kouskous
            </a>
            <a href="produits_accueil.php" class="text-gray-700 hover:text-bleu-canard transition">
                <i class="fas fa-arrow-left mr-2"></i> Continuer les achats
            </a>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-12">
        <h1 class="text-4xl font-bold text-bleu-canard mb-8 text-center">Votre Panier</h1>

        <?php if (empty($panier)): ?>
            <div class="text-center py-16 bg-white rounded-lg shadow-md">
                <i class="fas fa-shopping-cart text-5xl text-gray-300 mb-4"></i>
                <p class="text-xl text-gray-600">Votre panier est actuellement vide.</p>
                <a href="produits_accueil.php" class="mt-6 inline-block bg-bleu-canard hover:bg-bleu-canard-fonce text-white font-semibold py-2 px-6 rounded-lg transition duration-300">
                    Découvrir nos produits
                </a>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                <div class="hidden md:grid grid-cols-6 gap-4 p-4 font-semibold text-gray-600 border-b bg-gray-50">
                    <div class="col-span-2">Produit</div>
                    <div class="text-right">Prix Unitaire</div>
                    <div class="text-center">Quantité</div>
                    <div class="text-right">Sous-total</div>
                    <div></div>
                </div>

                <?php foreach ($panier as $id_produit => $quantite): ?>
                    <?php if (isset($produits_panier[$id_produit])):
                        $produit = $produits_panier[$id_produit];
                        $sous_total = $produit['prix'] * $quantite;
                        $total_general += $sous_total;
                        ?>
                        <div class="grid grid-cols-1 md:grid-cols-6 gap-4 items-center p-4 border-b">
                            <!-- Product Info -->
                            <div class="col-span-2 flex items-center">
                                <img src="uploads/<?php echo htmlspecialchars($produit['image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($produit['nom']); ?>" class="w-20 h-20 object-cover rounded-md mr-4">
                                <div>
                                    <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($produit['nom']); ?></p>
                                    <a href="retirer_panier.php?id=<?php echo $id_produit; ?>" class="text-red-500 hover:text-red-700 text-sm md:hidden">
                                        <i class="fas fa-trash-alt mr-1"></i>Supprimer
                                    </a>
                                </div>
                            </div>
                            <!-- Price -->
                            <div class="text-right">
                                <span class="md:hidden font-semibold">Prix: </span>
                                <?php echo number_format($produit['prix'], 2, ',', ' '); ?> MAD
                            </div>
                            <!-- Quantity -->
                            <div class="text-center">
                                <span class="md:hidden font-semibold">Qté: </span>
                                <?php echo $quantite; ?>
                            </div>
                            <!-- Subtotal -->
                            <div class="text-right font-semibold">
                                <span class="md:hidden">Sous-total: </span>
                                <?php echo number_format($sous_total, 2, ',', ' '); ?> MAD
                            </div>
                            <!-- Action -->
                            <div class="text-center hidden md:block">
                                <a href="retirer_panier.php?id=<?php echo $id_produit; ?>" class="text-red-500 hover:text-red-700" title="Supprimer l'article">
                                    <i class="fas fa-trash-alt fa-lg"></i>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>

                <!-- Totals and Actions -->
                <div class="p-6 bg-gray-50">
                    <div class="flex justify-end items-center">
                        <span class="text-lg font-semibold text-gray-700 mr-4">Total Général:</span>
                        <span class="text-2xl font-bold text-bleu-canard"><?php echo number_format($total_general, 2, ',', ' '); ?> MAD</span>
                    </div>
                    <div class="flex justify-between items-center mt-8">
                        <a href="produits_accueil.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded-lg transition duration-300">
                            <i class="fas fa-arrow-left mr-2"></i> Continuer les achats
                        </a>
                        <a href="commande.php" class="bg-bleu-canard hover:bg-bleu-canard-fonce text-white font-bold py-2 px-6 rounded-lg transition duration-300">
                            Passer la commande <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
