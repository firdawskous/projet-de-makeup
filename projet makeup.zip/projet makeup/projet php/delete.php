<?php 
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}
if ($id) {
    try {
        $stmt_select = $pdo->prepare("SELECT image FROM produit WHERE id = :id");
        $stmt_select->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt_select->execute();
        $produit = $stmt_select->fetch(PDO::FETCH_ASSOC);

        $stmt_delete = $pdo->prepare("DELETE FROM produit WHERE id = :id");
        $stmt_delete->bindParam(':id', $id, PDO::PARAM_INT);
        
        if ($stmt_delete->execute()) {
            if ($produit && !empty($produit['image'])) {
                $image_path = 'uploads/' . $produit['image'];
                if (file_exists($image_path)) {
                    unlink($image_path); 
                }
            }
            header("location:table.php?status=deleted");
            exit();
        } else {
            header("location:table.php?status=error_deleting_db");
            exit();
        }
    } catch (PDOException $e) {
        die("Erreur lors de la suppression du produit: " . $e->getMessage());
    }
}
header("location:table.php?status=invalid_id"); 
?>
