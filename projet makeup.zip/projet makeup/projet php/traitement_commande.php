<?php
session_start();

// 1. Sécurité : L'utilisateur doit être connecté et la méthode doit être POST
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: connexion.php");
    exit();
}

// 2. Vérification : Le panier ne doit pas être vide
$panier = $_SESSION['panier'] ?? [];
if (empty($panier)) {
    header("Location: panier.php");
    exit();
}

// 3. Validation du formulaire
$adresse = trim($_POST['adresse'] ?? '');
$ville = trim($_POST['ville'] ?? '');
$code_postal = trim($_POST['code_postal'] ?? '');

if (empty($adresse) || empty($ville) || empty($code_postal)) {
    header("Location: commande.php?error=missing_fields");
    exit();
}

// Connexion à la base de données
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

try {
    // Démarrer une transaction
    $pdo->beginTransaction();

    // Récupérer les informations des produits pour calculer le total final
    $ids = array_keys($panier);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt_produits = $pdo->prepare("SELECT id, prix FROM produit WHERE id IN ($placeholders)");
    $stmt_produits->execute($ids);
    $produits_db = $stmt_produits->fetchAll(PDO::FETCH_KEY_PAIR); // [id => prix]

    $total_final = 0;
    foreach ($panier as $id_produit => $quantite) {
        if (isset($produits_db[$id_produit])) {
            $total_final += $produits_db[$id_produit] * $quantite;
        }
    }

    // 4. Insérer la commande dans la table `commandes`
    $stmt_commande = $pdo->prepare(
        "INSERT INTO commandes (id_client, total, adresse_livraison, ville, code_postal) VALUES (?, ?, ?, ?, ?)"
    );
    $stmt_commande->execute([$_SESSION['user_id'], $total_final, $adresse, $ville, $code_postal]);

    // Récupérer l'ID de la commande qui vient d'être créée
    $id_commande = $pdo->lastInsertId();

    // 5. Insérer chaque produit de la commande dans la table `commande_produits`
    $stmt_details = $pdo->prepare(
        "INSERT INTO commande_produits (id_commande, id_produit, quantite, prix_unitaire) VALUES (?, ?, ?, ?)"
    );
    foreach ($panier as $id_produit => $quantite) {
        if (isset($produits_db[$id_produit])) {
            $stmt_details->execute([$id_commande, $id_produit, $quantite, $produits_db[$id_produit]]);
        }
    }

    // Si tout s'est bien passé, on valide la transaction
    $pdo->commit();

    // 6. Vider le panier
    unset($_SESSION['panier']);

    // 7. Définir un message de confirmation dans la session et rediriger
    $_SESSION['order_confirmation'] = "Votre commande n°" . $id_commande . " a été passée avec succès ! Merci pour votre confiance.";
    header("Location: produits_accueil.php");
    exit();

} catch (Exception $e) {
    // En cas d'erreur, on annule tout
    $pdo->rollBack();
    die("Une erreur est survenue lors de la commande. Veuillez réessayer. Erreur: " . $e->getMessage());
}
?>
