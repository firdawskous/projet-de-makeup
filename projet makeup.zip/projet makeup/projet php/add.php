<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {

    die("Erreur de connexion à la base de données: " . $e->getMessage());
}


if (isset($_POST['ok'])) {
    $nom = $_POST['nom'] ?? '';
    $type = $_POST['type'] ?? '';
    $code = $_POST['code'] ?? '';
    $marque = $_POST['marque'] ?? '';
    $prix = $_POST['prix'] ?? 0;
    $disponibilite = $_POST['disponibilite'] ?? '';
    $image_filename = null;

    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/'; 
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true); 
        }

        $tmp_name = $_FILES['image']['tmp_name'];
        $original_filename = basename($_FILES['image']['name']);
        $safe_filename = preg_replace("/[^A-Za-z0-9._-]/", "", $original_filename);
        $image_filename = uniqid() . "_" . $safe_filename;
        $target_path = $upload_dir . $image_filename;

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($tmp_name);

        if (in_array($file_type, $allowed_types)) {
            if (!move_uploaded_file($tmp_name, $target_path)) {
                die("Erreur lors du déplacement du fichier image téléversé.");
                $image_filename = null; 
            }
        } else {
            die("Type de fichier non autorisé. Uniquement JPG, PNG, GIF.");
            $image_filename = null; 
        }
    } elseif (isset($_FILES['image']) && $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
      
        die("Erreur de téléversement de l'image : " . $_FILES['image']['error']);
    }

    try {
       $sql = "INSERT INTO produit (nom, type, code, marque, prix, disponibilite, image) 
                VALUES (:nom, :type, :code, :marque, :prix, :disponibilite, :image)";
        $stmt = $pdo->prepare($sql);
        
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':code', $code);
        $stmt->bindParam(':marque', $marque);
        $stmt->bindParam(':prix', $prix);
        $stmt->bindParam(':disponibilite', $disponibilite);
        $stmt->bindParam(':image', $image_filename); 

        $stmt->execute();
        
        header("location:table.php");
        exit();
    } catch (PDOException $e) {
        die("Erreur lors de l'insertion du produit: " . $e->getMessage());
    }
} else {
    echo "Le formulaire n'a pas été soumis correctement.";
}
?>