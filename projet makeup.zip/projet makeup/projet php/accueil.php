<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $stmt = $pdo->query("SELECT nom, prix, image, disponibilite FROM produit WHERE disponibilite != 'out-of-stock' ORDER BY id DESC LIMIT 3");
    $produits_phares = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $produits_phares = [];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>firdaws kouskous | Produits Premium</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080',
                        'bleu-canard-fonce': '#006666',
                        'beige-fonce': '#E5E5CB',
                    }
                }
            }
        }
    </script>
    <style>
        .hero-gradient {
            background: linear-gradient(135deg, rgba(245, 245, 220, 0.9) 0%, #000080 100%);
        }
        
        .product-card {
            transition: all 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .nav-link::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: #000080;
            transition: width 0.3s;
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        
        .floating {
            animation: float 6s ease-in-out infinite;
        }

        .mobile-menu {
            transition: all 0.3s ease-out;
            max-height: 0;
            overflow: hidden;
        }

        .mobile-menu.open {
            max-height: 1000px;
        }

        body.menu-open {
            overflow: hidden;
        }
    </style>
</head>
<body class="bg-beige font-sans">

    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-4 sm:px-6 py-3">
            <div class="flex items-center justify-between">

                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                    <span class="text-bleu-canard font-semibold text-xl">firdaws kouskous</span>
                </div>
                

                <div class="hidden md:flex items-center space-x-6 lg:space-x-8">
                    <a href="accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Accueil</a>
                    <a href="produits_accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Produits</a>
                    <a href="#collection" class="nav-link text-gray-700 hover:text-bleu-canard transition">Collections</a>
                    <a href="#apropos" class="nav-link text-gray-700 hover:text-bleu-canard transition">À propos</a>
                    <a href="contact.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Contact</a>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard">
                        <i class="fas fa-search"></i>
                    </button>
                    <button class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard">
                        <a href="connexion.php"><i class="fas fa-user"></i></a>
                    </button>
                    <button class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard relative">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="absolute -top-2 -right-2 bg-bleu-canard text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
                    </button>
               
                    <button id="mobile-menu-button" class="md:hidden text-gray-700 focus:outline-none">
                        <i id="mobile-menu-icon" class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>
        
        <div id="mobile-menu" class="mobile-menu md:hidden bg-white border-t border-gray-200">
            <div class="container mx-auto px-4 py-2">
                <a href="accueil.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Accueil</a>
                <a href="produits_accueil.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Produits</a>
                <a href="#collection" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Collections</a>
                <a href="#apropos" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">À propos</a>
                <a href="contact.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Contact</a>
                <div class="border-t border-gray-200 mt-2 pt-2">
                    <a href="connexion.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">
                        <i class="fas fa-user mr-2"></i>Connexion
                    </a>
                    <a href="#" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">
                        <i class="fas fa-shopping-cart mr-2"></i>Panier
                        <span class="ml-2 bg-bleu-canard text-white text-xs rounded-full px-2 py-1">3</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <section class="hero-gradient py-16 md:py-20">
        <div class="container mx-auto px-6 flex flex-col md:flex-row items-center">
            <div class="md:w-1/2 mb-10 md:mb-0">
                <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold text-bleu-canard mb-6">Découvrez des produits Naturelle</h1>
                <p class="text-gray-700 text-lg mb-8">Des produits artisanaux qui marient parfaitement le beige apaisant et le bleu canard raffiné pour un style intemporel.</p>
                <a href="produits_accueil.php" class="bg-bleu-canard hover:bg-bleu-canard-fonce text-white font-bold py-3 px-8 rounded-full transition duration-300 transform hover:scale-105 inline-block">
                    Explorer la collection
                </a>
            </div>
            <div class="md:w-1/2 flex justify-center">
                <?php 
                    $hero_image = 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80';
                    if (!empty($produits_phares) && !empty($produits_phares[0]['image'])) {
                        $hero_image = 'uploads/' . htmlspecialchars($produits_phares[0]['image']);
                    }
                ?>
                <img src="<?php echo $hero_image; ?>" alt="Produits élégants" class="rounded-lg shadow-xl floating max-w-md w-full h-auto object-cover" style="max-height: 450px;">
            </div>
        </div>
    </section>

    <section class="py-12 md:py-16 bg-beige-fonce" id="collection">
        <div class="container mx-auto px-6">
            <h2 class="text-2xl md:text-3xl font-bold text-center text-bleu-canard mb-8 md:mb-12">Nos Produits Phares</h2>
            
            <?php if (!empty($produits_phares)): ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                    <?php foreach ($produits_phares as $produit): ?>

                    <div class="product-card bg-white rounded-lg overflow-hidden shadow-md transition duration-300 flex flex-col">
                        <div class="relative w-full h-64">
                            <?php if (!empty($produit['image'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($produit['image']); ?>" alt="<?php echo htmlspecialchars($produit['nom']); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <div class="w-full h-full bg-gray-200 flex items-center justify-center">
                                    <i class="fas fa-image fa-3x text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="p-4 md:p-6 flex-grow flex flex-col">
                            <h3 class="text-lg md:text-xl font-semibold text-gray-800 mb-2"><?php echo htmlspecialchars($produit['nom']); ?></h3>
                            <p class="text-gray-600 mb-4 flex-grow">Découvrez ce produit exceptionnel, sélectionné pour sa qualité.</p>
                            <div class="flex justify-between items-center mt-auto">
                                <span class="font-bold text-bleu-canard-fonce text-lg md:text-xl"><?php echo htmlspecialchars(number_format((float)$produit['prix'], 2, ',', ' ')); ?> MAD</span>
                                <button class="bg-beige hover:bg-bleu-canard text-bleu-canard hover:text-white px-3 py-1 md:px-4 md:py-2 rounded-full transition">
                                    <i class="fas fa-shopping-cart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-10">
                    <i class="fas fa-box-open text-4xl text-gray-400 mb-4"></i>
                    <p class="text-xl text-gray-600">Nos produits phares seront bientôt de retour.</p>
                    <p class="text-gray-500 mt-2">Revenez nous voir bientôt !</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="py-12 md:py-16 bg-white" id="apropos">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row items-center">
                <div class="md:w-1/2 mb-10 md:mb-0 md:pr-6 lg:pr-12">
                    <img src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" alt="Produits de maquillage élégants" class="rounded-lg shadow-xl w-full h-auto object-cover" style="max-height: 480px;">
                </div>
                <div class="md:w-1/2 md:pl-6 lg:pl-12" >
                    <h2 class="text-2xl md:text-3xl font-bold text-bleu-canard mb-6">Notre Philosophie</h2>
                    <p class="text-gray-700 mb-6">Chez Maquillage Naturelle, nous croyons en l’alliance parfaite entre beauté authentique et élégance raffinée. Nos teintes douces et naturelles, allant du beige nude au bleu profond, révèlent votre éclat tout en respectant votre peau.</p>
                    <p class="text-gray-700 mb-6">Chaque produit est formulé avec des ingrédients soigneusement sélectionnés et conçu pour sublimer sans masquer. Nous nous engageons à offrir un maquillage à la fois sophistiqué, sensoriel et respectueux de l’environnement, pour une beauté consciente et éclatante au quotidien.</p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="bg-beige p-4 rounded-lg flex items-center">
                            <div class="bg-bleu-canard text-white p-3 rounded-full mr-4">
                                <i class="fas fa-leaf text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-bleu-canard">Matériaux naturels</h4>
                                <p class="text-sm text-gray-600">100% écologiques</p>
                            </div>
                        </div>
                        <div class="bg-beige p-4 rounded-lg flex items-center">
                            <div class="bg-bleu-canard text-white p-3 rounded-full mr-4">
                                <i class="fas fa-hands-helping text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-bleu-canard">Artisanat local</h4>
                                <p class="text-sm text-gray-600">Fabriqué en France</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-12 md:py-16 bg-bleu-canard text-white">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-2xl md:text-3xl font-bold mb-6">Abonnez-vous à notre newsletter</h2>
            <p class="mb-8 max-w-2xl mx-auto">Recevez en exclusivité nos nouvelles collections, offres spéciales et conseils déco directement dans votre boîte mail.</p>
            
            <div class="max-w-md mx-auto flex flex-col sm:flex-row">
                <input type="email" placeholder="Votre adresse email" class="flex-grow px-4 py-3 rounded-full sm:rounded-l-full sm:rounded-r-none mb-2 sm:mb-0 focus:outline-none text-gray-800">
                <button class="bg-beige text-bleu-canard font-semibold px-6 py-3 rounded-full sm:rounded-r-full sm:rounded-l-none hover:bg-beige-fonce transition">
                    S'abonner
                </button>
            </div>
        </div>
    </section>

    <footer class="bg-gray-900 text-white pt-12 pb-6">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                        <span class="text-xl font-semibold">firdaws kouskous</span>
                    </div>
                    <p class="text-gray-400 mb-4">Des produits artisanaux qui marient élégance et naturel pour votre intérieur.</p>
                    <div class="flex space-x-4">
                        <a href="https://web.facebook.com/?_rdc=1&_rdr#" class="text-gray-400 hover:text-beige transition"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/" class="text-gray-400 hover:text-beige transition"><i class="fab fa-instagram"></i></a>
                        <a href="https://fr.pinterest.com/" class="text-gray-400 hover:text-beige transition"><i class="fab fa-pinterest-p"></i></a>
                        <a href="https://x.com/" class="text-gray-400 hover:text-beige transition"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Navigation</h3>
                    <ul class="space-y-2">
                        <li><a href="accueil.php" class="text-gray-400 hover:text-beige transition">Accueil</a></li>
                        <li><a href="produits_accueil.php" class="text-gray-400 hover:text-beige transition">Produits</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Collections</a></li>
                        <li><a href="contact.php" class="text-gray-400 hover:text-beige transition">Contact</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Informations</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Livraison</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Retours</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Politique de confidentialité</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Conditions générales</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">FAQ</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Contact</h3>
                    <ul class="space-y-2">
                        <li class="flex items-center text-gray-400"><i class="fas fa-map-marker-alt mr-2 text-beige"></i> 71 ait khassa 02 hamria khenifra</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-phone-alt mr-2 text-beige"></i> +212 682114015</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-envelope mr-2 text-beige"></i> kouskousfirdaws@gmail.com</li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-400 text-sm mb-4 md:mb-0">© <?php echo date('Y'); ?> firdaws kouskous. Tous droits réservés.</p>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-beige text-sm">Mentions légales</a>
                    <a href="#" class="text-gray-400 hover:text-beige text-sm">CGV</a>
                </div>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            const productCards = document.querySelectorAll('.product-card');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.1 });
            
            productCards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(card);
            });
            
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileMenuIcon = document.getElementById('mobile-menu-icon');

            mobileMenuButton.addEventListener('click', function(e) {
                e.stopPropagation();
                
                mobileMenu.classList.toggle('open');
                
                if (mobileMenu.classList.contains('open')) {
                    document.body.classList.add('menu-open');
                } else {
                    document.body.classList.remove('menu-open');
                }

                mobileMenuIcon.classList.toggle('fa-bars');
                mobileMenuIcon.classList.toggle('fa-times');
            });

            document.querySelectorAll('#mobile-menu a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.remove('open');
                    mobileMenuIcon.classList.remove('fa-times');
                    mobileMenuIcon.classList.add('fa-bars');
                    document.body.classList.remove('menu-open');
                });
            });

            document.addEventListener('click', function(event) {
                if (!mobileMenu.contains(event.target) {
                    mobileMenu.classList.remove('open');
                    mobileMenuIcon.classList.remove('fa-times');
                    mobileMenuIcon.classList.add('fa-bars');
                    document.body.classList.remove('menu-open');
                }
            });
        });
    </script>
</body>
</html>