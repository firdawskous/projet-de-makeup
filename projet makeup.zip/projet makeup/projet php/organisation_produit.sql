-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 08 août 2025 à 13:59
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `organisation_produit`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `email`, `telephone`, `password`, `confirmer`) VALUES
(2, 'kouskous', 'firdaws', 'admin@gmail.com', '0682114015', '$2y$10$h1HG5CjK7iFRNHTT4qBU0eoTZvSKv7dktz3XmWprQH0k5IyDJRqve', ''),
(3, 'abekhar', 'hiba', 'hiba@gmail.com', '09753579', '$2y$10$EvY/s9lY5SCQeSBtOJ4t1ebU3GQdf6nIpSpyywsu8YRBohHTVBBGK', ''),
(4, 'kouskous', 'Nouhayla', 'nouha@gmail.com', '0682113999', '$2y$10$q14vw3MadTPffnROs/AqtOryHppiAt62ffH3oEKHuqy1NWO9nSFMG', ''),
(5, 'el watiq', 'khawla', 'khawla@gmail.com', '076543456789', '$2y$10$jeHUFVuHeRqG2Gc6.kPHye0jq8D.0MC9NtaJ8VgQedx6FXKXwVUNW', '');

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

CREATE TABLE `commandes` (
  `id_commande` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `date_commande` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `adresse_livraison` varchar(255) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `code_postal` varchar(20) NOT NULL,
  `statut` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commandes`
--

INSERT INTO `commandes` (`id_commande`, `id_client`, `date_commande`, `total`, `adresse_livraison`, `ville`, `code_postal`, `statut`) VALUES
(1, 3, '0000-00-00 00:00:00', 2285.00, 'Ait Khassa 02 Hamria Khénifra', 'Khénifra', '54000', ''),
(2, 5, '0000-00-00 00:00:00', 135.00, 'el manal', 'rabat', '2000', ''),
(3, 5, '0000-00-00 00:00:00', 1050.00, '71 ait khassa 2 hamria', 'sale', '50000', '');

-- --------------------------------------------------------

--
-- Structure de la table `commande_produits`
--

CREATE TABLE `commande_produits` (
  `id` int(11) NOT NULL,
  `id_commande` int(11) NOT NULL,
  `id_produit` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande_produits`
--

INSERT INTO `commande_produits` (`id`, `id_commande`, `id_produit`, `quantite`, `prix_unitaire`) VALUES
(1, 1, 13, 1, 100.00),
(2, 1, 14, 1, 30.00),
(3, 1, 15, 2, 1000.00),
(4, 1, 16, 1, 45.00),
(5, 1, 9, 1, 50.00),
(6, 1, 11, 1, 20.00),
(7, 1, 10, 1, 40.00),
(8, 2, 14, 1, 30.00),
(9, 2, 9, 1, 50.00),
(10, 2, 11, 1, 20.00),
(11, 2, 12, 1, 35.00),
(12, 3, 15, 1, 1000.00),
(13, 3, 9, 1, 50.00);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id` int(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `code` varchar(100) NOT NULL,
  `marque` varchar(100) NOT NULL,
  `prix` varchar(40) NOT NULL,
  `disponibilite` varchar(30) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id`, `nom`, `type`, `code`, `marque`, `prix`, `disponibilite`, `image`) VALUES
(9, 'Fond de teint', 'makeup', 'f1', 'essence', '50', 'in-stock', '6856a00078cd7_fond1.jpeg'),
(10, 'mascara', 'makeup', 'm1', 'essence', '40', 'pre-order', '68569fb7d942a_mascara1.jpeg'),
(11, 'highlighter', 'makeup', 'h1', 'essence', '20', 'in-stock', '6856a04f094ec_highlighter1.jpeg'),
(12, 'lip gloss', 'alimentaire', 'L1', 'essence', '35', 'in-stock', '68568ddc06eb3_lipglos1.jpeg'),
(13, 'blush', 'alimentaire', 'b1', 'catrice', '100', 'in-stock', '685690185c825_blush1.jpeg'),
(14, 'eyeliner', 'alimentaire', 'E1', 'essence', '30', 'pre-order', '6856b165cc0a1_eyeliner1.jpeg'),
(15, 'lip gloss', 'alimentaire', 'l2', 'dior', '1000', 'in-stock', '6856b1ad91087_lip_tint1.jpeg'),
(16, 'lip tint', 'alimentaire', 'L3', 'essence', '45', 'in-stock', '6856b1f77a020_lip_tint2.jpeg');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_client` (`id_client`);

--
-- Index pour la table `commande_produits`
--
ALTER TABLE `commande_produits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_commande` (`id_commande`),
  ADD KEY `id_produit` (`id_produit`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `commandes`
--
ALTER TABLE `commandes`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `commande_produits`
--
ALTER TABLE `commande_produits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `commande_produits`
--
ALTER TABLE `commande_produits`
  ADD CONSTRAINT `commande_produits_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commandes` (`id_commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_produits_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
