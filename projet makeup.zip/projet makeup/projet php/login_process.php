<?php
session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login']) && isset($_POST['password'])) {
    $email_input = trim(filter_input(INPUT_POST, 'login', FILTER_SANITIZE_EMAIL)); // 'login' field is used for email
    $password_input = $_POST['password'];

    if (empty($email_input) || empty($password_input)) {
        header("Location: connexion.php?error=2"); 
        exit();
    }
    if (!filter_var($email_input, FILTER_VALIDATE_EMAIL)) {
        header("Location: connexion.php?error=invalid_email");
        exit();
    }
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        $sql = "SELECT id, nom, prenom, email, password FROM client WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email_input);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password_input, $user['password'])) {

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nom'] = $user['nom'];
            $_SESSION['user_prenom'] = $user['prenom'];
            $_SESSION['user_email'] = $user['email'];

            $admin_emails = ['admin@gmail.com', 'administrateur@gmail.com'];
            if (in_array(strtolower($user['email']), $admin_emails)) {
                $_SESSION['user_role'] = 'admin';
                header("Location: table.php?login=success_admin");
            } else {
                $_SESSION['user_role'] = 'user';
                header("Location: produits_accueil.php?login=success_user");
            }
            exit();
        } else {

            header("Location: connexion.php?error=1");
            exit();
        }

    } catch (PDOException $e) {
        
        die("Erreur de base de données lors de la connexion : " . $e->getMessage());
        
    }
} else {
    header("Location: connexion.php");
    exit();
}