<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un nouveau produit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC', 
                        navy: {
                            '50': '#f0f4ff',
                            '100': '#dde6ff',
                            '200': '#c2d3ff',
                            '300': '#9cb6ff',
                            '400': '#758dff',
                            '500': '#4f61ff',
                            '600': '#2f3af5',
                            '700': '#222ad8',
                            '800': '#2128ae',
                            '900': '#212989',
                            '950': '#131652',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow {
            box-shadow: 0 10px 25px -5px rgba(19, 22, 82, 0.2), 0 10px 10px -5px rgba(19, 22, 82, 0.04);
        }
        .input-focus:focus {
            border-color: #4f61ff;
            box-shadow: 0 0 0 3px rgba(79, 97, 255, 0.2);
        }
        .form1{
            background: linear-gradient(135deg, rgba(245, 245, 220, 0.2) 0%, rgba(0, 0, 128, 0.1) 100%); /* Teinte du gradient changée en bleu marine */

        }
    </style>
</head>
<body class="bg-beige min-h-screen"> 
    <div class="container mx-auto px-4 py-8">

        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-navy-900">
                <i class="fas fa-box-open mr-3 text-navy-700"></i>
                Ajouter un nouveau produit
            </h1>
            <button class="bg-navy-700 hover:bg-navy-800 text-white px-4 py-2 rounded-lg transition duration-200 flex items-center">
                <i class="fas fa-list mr-2"></i> Voir tous les produits
            </button>
        </div>

        <div class="bg-white rounded-xl custom-shadow overflow-hidden">
            <div class="bg-navy-700 px-6 py-4">
                <h2 class="text-xl font-semibold text-white">
                    <i class="fas fa-info-circle mr-2"></i> Informations du produit
                </h2>
            </div>

            <form class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 form1" action="add.php" method="post" enctype="multipart/form-data">
                <div class="space-y-2">
                    <label for="product-name" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-tag mr-2 text-navy-700"></i> Nom du produit *
                    </label>
                    <div class="relative">
                        <input type="text" name="nom" id="product-name" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg input-focus focus:outline-none transition duration-200"
                            placeholder="Ex: T-shirt en coton">
                        <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                            <i class="fas fa-check-circle text-green-500 opacity-0" id="name-valid"></i>
                        </div>
                    </div>
                </div>

                <div class="space-y-2">
                    <label for="product-type" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-list-alt mr-2 text-navy-700"></i> Type de produit *
                    </label>
                    <select id="product-type" name="type" required 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg input-focus focus:outline-none transition duration-200 appearance-none bg-white">
                        <option value="" disabled selected>Sélectionnez un type</option>
                        <option value="vetement">Vêtement</option>
                        <option value="electronique">Électronique</option>
                        <option value="meuble">parfum</option>
                        <option value="alimentaire">makeup</option>
                        <option value="autre">Autre</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                        <i class="fas fa-chevron-down"></i>
                    </div>
                </div>

                <div class="space-y-2">
                    <label for="product-code" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-barcode mr-2 text-navy-700"></i> Code produit *
                    </label>
                    <div class="relative">
                        <input type="text" name="code" id="product-code" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg input-focus focus:outline-none transition duration-200"
                            placeholder="Ex: PROD-12345">
                        <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                            <button type="button" class="text-navy-700 hover:text-navy-900" title="Générer un code">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="space-y-2">
                    <label for="product-brand" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-copyright mr-2 text-navy-700"></i> Marque *
                    </label>
                    <input type="text" name="marque" id="product-brand" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg input-focus focus:outline-none transition duration-200"
                        placeholder="Ex: Nike">
                </div>

                <div class="space-y-2">
                    <label for="product-price" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-euro-sign mr-2 text-navy-700"></i> Prix *
                    </label>
                    <div class="relative">
                        <input type="number" name="prix" id="product-price" min="0" step="0.01" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg input-focus focus:outline-none transition duration-200 pl-8"
                            placeholder="Entrez le prix en MAD.">
                       
                    </div>
                </div>

                <div class="space-y-2">
                    <label class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-store mr-2 text-navy-700"></i> Disponibilité *
                    </label>
                    <div class="flex space-x-4">
                        <label class="inline-flex items-center">
                            <input type="radio" name="disponibilite" value="in-stock" checked
                                class="form-radio text-navy-700 focus:ring-navy-700">
                            <span class="ml-2">En stock</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="disponibilite" value="out-of-stock"
                                class="form-radio text-navy-700 focus:ring-navy-700">
                            <span class="ml-2">Rupture de stock</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="disponibilite" value="pre-order"
                                class="form-radio text-navy-700 focus:ring-navy-700">
                            <span class="ml-2">Pré-commande</span>
                        </label>
                    </div>
                </div>

                <div class="md:col-span-2 space-y-2">
                    <label for="product-image" class="block text-sm font-medium text-navy-900">
                        <i class="fas fa-image mr-2 text-navy-700"></i> Image du produit
                    </label>
                    <input type="file" name="image" id="product-image" accept="image/png, image/jpeg, image/gif"
                        class="w-full text-sm text-gray-500 border border-gray-300 rounded-lg cursor-pointer
                               file:mr-4 file:py-2 file:px-4
                               file:rounded-l-lg file:border-0
                               file:text-sm file:font-semibold
                               file:bg-navy-50 file:text-navy-700
                               hover:file:bg-navy-100 input-focus focus:outline-none transition duration-200">
                </div>
                

                <div class="md:col-span-2 flex justify-end space-x-4 pt-4 border-t border-gray-200">
                    <button type="reset"  class="px-6 py-2 border border-gray-300 rounded-lg text-navy-900 hover:bg-gray-50 transition duration-200">
                        <i class="fas fa-undo mr-2"></i> Réinitialiser
                    </button>
                    <button type="submit" name="ok" class="px-6 py-2 bg-navy-700 hover:bg-navy-800 text-white rounded-lg transition duration-200 flex items-center">
                        <i class="fas fa-save mr-2"></i> Enregistrer le produit
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('product-name').addEventListener('input', function(e) {
            const validIcon = document.getElementById('name-valid');
            if (e.target.value.length > 2) {
                validIcon.classList.remove('opacity-0');
                validIcon.classList.add('opacity-100');
            } else {
                validIcon.classList.remove('opacity-100');
                validIcon.classList.add('opacity-0');
            }
        });

        const colorInput = document.querySelector('input[type="color"]');
        const colorText = document.getElementById('product-color');
        
        colorInput.addEventListener('input', function(e) {
            const color = e.target.value;
            const colorNames = {
                '#131652': 'Bleu marine',
                '#ff0000': 'Rouge',
                '#00ff00': 'Vert',
                '#0000ff': 'Bleu',
                '#ffff00': 'Jaune',
                '#ff00ff': 'Magenta',
                '#00ffff': 'Cyan',
                '#000000': 'Noir',
                '#ffffff': 'Blanc'
            };
            
            colorText.value = colorNames[color] || color;
        });
    </script>
    
</body>
</html>