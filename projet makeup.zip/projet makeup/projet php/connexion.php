<?php
session_start();

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
        header("Location: accueil.php");
        exit();
    } else {
        header("Location: produits_accueil.php"); 
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion | firdaws kouskous</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080', 
                        'bleu-canard-fonce': '#006666',
                        'beige-fonce': '#E5E5CB',
                    }
                }
            }
        }
    </script>
    <style>
        .login-container {
            background: linear-gradient(135deg, rgba(245, 245, 220, 0.2) 0%, rgba(0, 0, 128, 0.1) 100%); 
        }
        
        .input-focus:focus {
            border-color: #000080; 
            box-shadow: 0 0 0 3px rgba(0, 0, 128, 0.2); 
        }
        
        .btn-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 128, 0.2); 
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #E5E5CB;
        }
        
        .divider::before {
            margin-right: 1rem;
        }
        
        .divider::after {
            margin-left: 1rem;
        }
    </style>
</head>
<body class="bg-beige min-h-screen flex items-center justify-center p-4">
    
    <nav class="absolute top-0 left-0 w-full py-4 px-6 z-10">
        <a href="accueil.php" class="text-bleu-canard hover:text-bleu-canard-fonce font-semibold transition">
            <i class="fas fa-arrow-left mr-2"></i>
            Retour à l'accueil
        </a>
    </nav>
    <div class="login-container w-full max-w-md rounded-2xl overflow-hidden shadow-xl bg-white">
      
        <div class="bg-bleu-canard text-white p-8 text-center">
            <div class="w-16 h-16 rounded-full bg-white flex items-center justify-center text-bleu-canard font-bold text-2xl mx-auto mb-4">FK</div>
            <h1 class="text-2xl font-bold">Bienvenue chez produits Naturelle</h1>
            <p class="text-beige mt-2">Connectez-vous à votre compte</p>
        </div>
        
        <div class="p-8">
            <?php
            if (isset($_GET['error'])) {
                $error_message = '';
                if ($_GET['error'] == '1') $error_message = "Identifiant ou mot de passe incorrect.";
                if ($_GET['error'] == 'invalid_email') $error_message = "Format d'email invalide.";
                echo '<div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">' . htmlspecialchars($error_message) . '</div>';
            }
            ?>
            <form action="login_process.php" method="POST" id="loginForm">
                <div class="mb-6">
                    <label for="email" class="block text-gray-700 mb-2">Adresse email</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input 
                            type="email" 
                            id="email" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="login"
                            placeholder="votre@email.com"
                            required>
                    </div>
                </div>
                
                <div class="mb-6">
                    <label for="password" class="block text-gray-700 mb-2">Mot de passe</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input 
                            type="password" 
                            id="password" 
                            name="password"
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            placeholder="••••••••"
                            required>
                        <button type="button" class="absolute right-3 top-3 text-gray-400 hover:text-bleu-canard">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="flex justify-between items-center mt-2">
                        <div class="flex items-center">
                            <input type="checkbox" id="remember" class="rounded text-bleu-canard focus:ring-bleu-canard">
                            <label for="remember" class="ml-2 text-sm text-gray-600">Se souvenir de moi</label>
                        </div>
                        <a href="#" class="text-sm text-bleu-canard hover:text-bleu-canard-fonce hover:underline">Mot de passe oublié?</a>
                    </div>
                </div>
                
                <button 
                    type="submit" 
                    name="ok"
                    class="btn-hover w-full bg-bleu-canard text-white font-bold py-3 px-4 rounded-lg transition duration-300 hover:bg-bleu-canard-fonce mb-6">
                    Se connecter
                </button>
                
                <div class="flex items-center text-gray-400 text-sm mb-6 divider">
                    <span>OU</span>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-6">
                    <button 
                        type="button" 
                        class="flex items-center justify-center py-2 px-4 border rounded-lg hover:bg-gray-50 transition">
                        <i class="fab fa-google text-red-500 mr-2"></i>
                        <span>Google</span>
                    </button>
                    <button 
                        type="button" 
                        class="flex items-center justify-center py-2 px-4 border rounded-lg hover:bg-gray-50 transition">
                        <i class="fab fa-facebook-f text-blue-600 mr-2"></i>
                        <span>Facebook</span>
                    </button>
                </div>
                
                <div class="text-center text-gray-600">
                    <p>Pas encore de compte? <a href="inscription.php" class="text-bleu-canard hover:text-bleu-canard-fonce font-semibold hover:underline">S'inscrire</a></p>
                </div>
            </form>
        </div>
        
        <div class="bg-beige-fonce text-gray-600 text-center py-4 text-sm">
            <p>© 2023 firdaws kouskous. Tous droits réservés.</p>
        </div>
    </div>

    <script>

        document.querySelector('[type="password"]').nextElementSibling.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        
    </script>
</body>
</html>