<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: connexion.php?error=auth_required");
    exit();
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données. Veuillez réessayer plus tard.");
}

$stmt = $pdo->query("SELECT id, nom, prenom, email, telephone FROM client ORDER BY id DESC"); 
?>
<!DOCTYPE html>

<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Tableau des Clients</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: {
                            '50': '#f0f4ff',
                            '100': '#dde6ff',
                            '200': '#c2d3ff',
                            '300': '#9cb6ff',
                            '400': '#758dff',
                            '500': '#4f61ff',
                            '600': '#2f3af5',
                            '700': '#222ad8',
                            '800': '#2128ae',
                            '900': '#212989',
                            '950': '#131652',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
    </style>
</head>

<body class="bg-beige">
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-8">
                    <a href="table.php" class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-navy-700 flex items-center justify-center text-white font-bold text-xl mr-2">A</div>
                        <span class="text-navy-800 font-semibold text-xl">Admin</span>
                    </a>
                    <div class="hidden md:flex space-x-6">
                        <a href="table.php" class="text-gray-600 hover:text-navy-700 transition">Produits</a>
                        <a href="table_client.php" class="text-navy-700 font-semibold border-b-2 border-navy-700 pb-1">Clients</a>
                        <a href="accueil.php" class="text-gray-600 hover:text-navy-700 transition" target="_blank" title="Ouvrir la page d'accueil dans un nouvel onglet">
                            Voir le site <i class="fas fa-external-link-alt text-xs ml-1"></i>
                        </a>
                    </div>
                </div>
                
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600 hidden sm:block">
                        Bienvenue, <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? $_SESSION['user_nom']); ?>!
                    </span>
                    <a href="profil.php" class="text-gray-600 hover:text-navy-700" title="Mon Profil">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-sm transition duration-200 flex items-center" title="Déconnexion">
                        <i class="fas fa-sign-out-alt md:mr-2"></i>
                        <span class="hidden md:inline">Déconnexion</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-users mr-3 text-navy-600"></i>
                Tableau des Clients
            </h1>
            
        </div>
</div>

        <?php if (isset($_GET['status'])): ?>
            <?php
                $status = $_GET['status'];
                $messages = [
                    'deleted_success' => ['type' => 'success', 'text' => 'Le client a été supprimé avec succès.'],
                    'updated_success' => ['type' => 'success', 'text' => 'Le client a été mis à jour avec succès.'],
                    'delete_error' => ['type' => 'error', 'text' => 'Erreur lors de la suppression du client.'],
                    'invalid_id' => ['type' => 'error', 'text' => 'ID de client non valide ou introuvable.'],
                    'not_found' => ['type' => 'error', 'text' => 'Client non trouvé.'],
                ];
                if (array_key_exists($status, $messages)) {
                    $message = $messages[$status];
                    $bgColor = $message['type'] === 'success' ? 'bg-green-100 border-green-400 text-green-700' : 'bg-red-100 border-red-400 text-red-700';
                    echo '<div class="mb-4 p-4 ' . $bgColor . ' rounded-lg text-sm" role="alert">';
                    echo '<i class="fas ' . ($message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle') . ' mr-2"></i>';
                    echo htmlspecialchars($message['text']);
                    echo '</div>';
                }
            ?>
        <?php endif; ?>
        <div class="bg-white rounded-lg custom-shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-navy-800 bg-navy-700">
                <h2 class="text-lg font-semibold text-white">
                    <i class="fas fa-users mr-2 text-navy-100"></i> Liste des clients
                </h2>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-navy-100">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-id-card mr-1"></i> ID
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-user mr-1"></i> Nom
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-user mr-1"></i> Prenom
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-envelope mr-1"></i> Email
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-phone mr-1"></i> Telephone
                            </th>
                            
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">
                                <i class="fas fa-cogs mr-1"></i> Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        ?>
                        <tr class="hover:bg-navy-50 transition duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['id']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['nom']); ?></div>
                            </td>
                             <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['prenom']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['email']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['telephone']); ?></div>
                            </td>
                           
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="update_client.php?id=<?php echo $row['id']; ?>" class="text-navy-600 hover:text-navy-900 mr-3" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="delete_client.php" method="POST" class="inline-block" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce client ?');">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-900" title="Supprimer">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                        </tr>
                        <?php
                        } 
                        if ($stmt->rowCount() === 0) {
                            echo '<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">Aucun client trouvé.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>