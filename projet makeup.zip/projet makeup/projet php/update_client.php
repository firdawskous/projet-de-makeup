<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: connexion.php?error=auth_required");
    exit();
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

$client = null;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $telephone = trim($_POST['telephone'] ?? '');

    if (!$id) $errors[] = "ID du client invalide.";
    if (empty($nom)) $errors[] = "Le nom est requis.";
    if (empty($prenom)) $errors[] = "Le prénom est requis.";
    if (!$email) $errors[] = "L'adresse email est invalide.";
    if (empty($telephone)) $errors[] = "Le numéro de téléphone est requis.";

    if (empty($errors)) {
        try {
            $sql = "UPDATE client SET nom = :nom, prenom = :prenom, email = :email, telephone = :telephone WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nom' => $nom,
                ':prenom' => $prenom,
                ':email' => $email,
                ':telephone' => $telephone,
                ':id' => $id
            ]);
            header("Location: table_client.php?status=updated_success");
            exit();
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la mise à jour du client.";
        }
    }
    $client = $_POST;

} else {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if (!$id) {
        header("Location: table_client.php?status=invalid_id");
        exit();
    }

    try {
        $stmt = $pdo->prepare("SELECT id, nom, prenom, email, telephone FROM client WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $client = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$client) {
            header("Location: table_client.php?status=not_found");
            exit();
        }
    } catch (PDOException $e) {
        die("Erreur lors de la récupération des informations du client: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le Client - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: { '50': '#f0f4ff', '100': '#dde6ff', '200': '#c2d3ff', '300': '#9cb6ff', '400': '#758dff', '500': '#4f61ff', '600': '#2f3af5', '700': '#222ad8', '800': '#2128ae', '900': '#212989', '950': '#131652' }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow { box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); }
        .input-focus:focus { border-color: #4f61ff; box-shadow: 0 0 0 3px rgba(79, 97, 255, 0.2); }
    </style>
</head>
<body class="bg-beige">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold text-navy-900">
                    <i class="fas fa-user-edit mr-3 text-navy-700"></i>
                    Modifier un Client
                </h1>
                <a href="table_client.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg transition duration-200 flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Annuler
                </a>
            </div>

            <div class="bg-white rounded-lg custom-shadow overflow-hidden">
                <div class="bg-navy-700 px-6 py-4">
                    <h2 class="text-xl font-semibold text-white">Informations de <?php echo htmlspecialchars($client['prenom'] ?? '') . ' ' . htmlspecialchars($client['nom'] ?? ''); ?></h2>
                </div>

                <form class="p-6 space-y-6" action="update_client.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($client['id']); ?>">
                    
                    <?php if (!empty($errors)): ?>
                        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                            <p class="font-bold">Erreurs de validation :</p>
                            <ul class="list-disc list-inside">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div>
                        <label for="nom" class="block text-sm font-medium text-navy-900">Nom</label>
                        <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($client['nom'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm input-focus focus:outline-none sm:text-sm">
                    </div>
                    <div>
                        <label for="prenom" class="block text-sm font-medium text-navy-900">Prénom</label>
                        <input type="text" name="prenom" id="prenom" value="<?php echo htmlspecialchars($client['prenom'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm input-focus focus:outline-none sm:text-sm">
                    </div>
                    <div>
                        <label for="email" class="block text-sm font-medium text-navy-900">Email</label>
                        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($client['email'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm input-focus focus:outline-none sm:text-sm">
                    </div>
                    <div>
                        <label for="telephone" class="block text-sm font-medium text-navy-900">Téléphone</label>
                        <input type="tel" name="telephone" id="telephone" value="<?php echo htmlspecialchars($client['telephone'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm input-focus focus:outline-none sm:text-sm">
                    </div>

                    <div class="flex justify-end pt-4 border-t border-gray-200">
                        <button type="submit" class="px-6 py-2 bg-navy-700 hover:bg-navy-800 text-white rounded-lg transition duration-200 flex items-center">
                            <i class="fas fa-save mr-2"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>