<?php

if(isset($_POST['ok'])){

    $login = trim(filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING));
    $password_plain = $_POST['password']; 
    if (empty($login) || empty($password_plain)) {
        die("Le login et le mot de passe ne peuvent pas être vides.");
    }

    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    try {
        $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        $sql = "INSERT INTO users (login, password) VALUES (:login, :password)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':login', $login);
        $stmt->bindParam(':password', $password_hashed);
        $stmt->execute();

        header("location:accueil.php?status=registered");
        exit(); 
    } catch (PDOException $e) {
        die("Erreur lors de l'enregistrement de l'utilisateur : " . $e->getMessage());
    }
}