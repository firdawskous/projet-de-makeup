<?php
session_start();

// 1. Sécurité : L'utilisateur doit être connecté pour commander
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php?error=auth_required_order");
    exit();
}

// 2. Vérification : Le panier ne doit pas être vide
$panier = $_SESSION['panier'] ?? [];
if (empty($panier)) {
    header("Location: panier.php?error=empty_cart");
    exit();
}

// Connexion à la base de données
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

// Récupérer les informations complètes des produits du panier
$produits_panier = [];
$total_general = 0;
$ids = array_keys($panier);
$placeholders = implode(',', array_fill(0, count($ids), '?'));

$stmt = $pdo->prepare("SELECT id, nom, prix, image FROM produit WHERE id IN ($placeholders)");
$stmt->execute($ids);
$produits_resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($produits_resultats as $produit) {
    $quantite = $panier[$produit['id']];
    $produit['quantite'] = $quantite;
    $produit['sous_total'] = $produit['prix'] * $quantite;
    $produits_panier[$produit['id']] = $produit;
    $total_general += $produit['sous_total'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finaliser la Commande</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080',
                        'bleu-canard-fonce': '#006666',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-beige">

    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <a href="accueil.php" class="text-bleu-canard font-semibold text-xl flex items-center">
                <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                firdaws kouskous
            </a>
            <a href="panier.php" class="text-gray-700 hover:text-bleu-canard transition">
                <i class="fas fa-arrow-left mr-2"></i> Retour au panier
            </a>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-12">
        <h1 class="text-4xl font-bold text-bleu-canard mb-8 text-center">Finaliser votre commande</h1>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <!-- Formulaire de livraison -->
            <div class="lg:col-span-2 bg-white p-8 rounded-lg shadow-lg">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 border-b pb-4">Adresse de livraison</h2>
                <?php if (isset($_GET['error'])): ?>
                    <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
                        Veuillez remplir tous les champs de l'adresse.
                    </div>
                <?php endif; ?>
                <form action="traitement_commande.php" method="POST">
                    <div class="space-y-6">
                        <div>
                            <label for="adresse" class="block text-sm font-medium text-gray-700">Adresse complète</label>
                            <input type="text" name="adresse" id="adresse" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-bleu-canard focus:border-bleu-canard">
                        </div>
                        <div>
                            <label for="ville" class="block text-sm font-medium text-gray-700">Ville</label>
                            <input type="text" name="ville" id="ville" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-bleu-canard focus:border-bleu-canard">
                        </div>
                        <div>
                            <label for="code_postal" class="block text-sm font-medium text-gray-700">Code Postal</label>
                            <input type="text" name="code_postal" id="code_postal" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-bleu-canard focus:border-bleu-canard">
                        </div>
                    </div>
                    <div class="mt-8 pt-6 border-t">
                        <button type="submit" class="w-full bg-bleu-canard hover:bg-bleu-canard-fonce text-white font-bold py-3 px-6 rounded-lg transition duration-300 text-lg">
                            <i class="fas fa-lock mr-2"></i> Valider et Payer (Total: <?php echo number_format($total_general, 2, ',', ' '); ?> MAD)
                        </button>
                    </div>
                </form>
            </div>

            <!-- Récapitulatif du panier -->
            <div class="bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 border-b pb-4">Récapitulatif</h2>
                <div class="space-y-4">
                    <?php foreach ($produits_panier as $produit): ?>
                    <div class="flex justify-between items-center">
                        <div class="flex items-center">
                            <img src="uploads/<?php echo htmlspecialchars($produit['image'] ?? 'default.jpg'); ?>" alt="<?php echo htmlspecialchars($produit['nom']); ?>" class="w-16 h-16 object-cover rounded-md mr-4">
                            <div>
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($produit['nom']); ?></p>
                                <p class="text-sm text-gray-500">Qté: <?php echo $produit['quantite']; ?></p>
                            </div>
                        </div>
                        <p class="font-semibold text-gray-700"><?php echo number_format($produit['sous_total'], 2, ',', ' '); ?> MAD</p>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-6 pt-6 border-t">
                    <div class="flex justify-between items-center text-lg">
                        <span class="font-semibold text-gray-700">Total</span>
                        <span class="font-bold text-bleu-canard"><?php echo number_format($total_general, 2, ',', ' '); ?> MAD</span>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>
</html>

