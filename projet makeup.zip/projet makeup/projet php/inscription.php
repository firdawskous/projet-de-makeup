<?php
session_start(); 
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
        header("Location: table.php");
    } else {
        header("Location: produits_accueil.php"); 
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription | firdaws kouskous</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080', 
                        'bleu-canard-fonce': '#006666',
                        'beige-fonce': '#E5E5CB',
                    }
                }
            }
        }
    </script>
    <style>
        .login-container {
            background: linear-gradient(135deg, rgba(245, 245, 220, 0.2) 0%, rgba(0, 0, 128, 0.1) 100%); /* Teinte du gradient changée en bleu marine */
        }
        
        .input-focus:focus {
            border-color: #000080; 
            box-shadow: 0 0 0 3px rgba(0, 0, 128, 0.2); 
        }
        
        .btn-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 128, 0.2); 
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #E5E5CB;
        }
        
        .divider::before {
            margin-right: 1rem;
        }
        
        .divider::after {
            margin-left: 1rem;
        }
    </style>
</head>
<body class="bg-beige min-h-screen flex items-center justify-center p-4">
     <nav class="absolute top-0 left-0 w-full py-4 px-6 z-10">
        <a href="accueil.php" class="text-bleu-canard hover:text-bleu-canard-fonce font-semibold transition">
            <i class="fas fa-arrow-left mr-2"></i>
            Retour à l'accueil
        </a>
    </nav>
    <div class="login-container w-full max-w-md rounded-2xl overflow-hidden shadow-xl bg-white">

        <div class="bg-bleu-canard text-white p-8 text-center">
            <div class="w-16 h-16 rounded-full bg-white flex items-center justify-center text-bleu-canard font-bold text-2xl mx-auto mb-4">FK</div>
            <h1 class="text-2xl font-bold">Bienvenue chez produits Naturelle</h1>
            <p class="text-beige mt-2">Créez votre compte pour commencer</p>
        </div>

        <div class="p-6 md:p-8">
            <div id="client-side-errors" class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm hidden">

            </div>

            <?php
            if (isset($_SESSION['inscription_errors']) && !empty($_SESSION['inscription_errors'])) {
                echo '<div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">';
                foreach ($_SESSION['inscription_errors'] as $error) {
                    echo '<p>' . htmlspecialchars($error) . '</p>';
                }
                echo '</div>';
                unset($_SESSION['inscription_errors']); 
            }
            $form_data = $_SESSION['form_data'] ?? []; 
            unset($_SESSION['form_data']);
            ?>
            <form action="register_process.php" method="POST" id="inscriptionForm">

                <div class="mb-6">
                    <label for="lastname" class="block text-gray-700 mb-2">Nom</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-user text-gray-400"></i>
                        </div>
                        <input 
                            type="text" 
                            id="lastname" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="nom"
                            value="<?php echo htmlspecialchars($form_data['nom'] ?? ''); ?>"
                            required>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="firstname" class="block text-gray-700 mb-2">Prénom</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-user text-gray-400"></i>
                        </div>
                        <input 
                            type="text" 
                            id="firstname" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="prenom"
                            value="<?php echo htmlspecialchars($form_data['prenom'] ?? ''); ?>"
                            required>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="email" class="block text-gray-700 mb-2">Adresse email</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input 
                            type="email" 
                            id="email" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="email"
                            value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>"
                            required>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="phone" class="block text-gray-700 mb-2">Numéro de téléphone</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-phone text-gray-400"></i>
                        </div>
                        <input 
                            type="tel" 
                            id="phone" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="telephone"
                            value="<?php echo htmlspecialchars($form_data['telephone'] ?? ''); ?>"
                            required>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="password" class="block text-gray-700 mb-2">Mot de passe</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input 
                            type="password" 
                            id="password" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="password"
                            placeholder="••••••••"
                            required>
                        <button type="button" id="togglePassword" class="absolute right-3 top-3 text-gray-400 hover:text-bleu-canard">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="confirm-password" class="block text-gray-700 mb-2">Confirmer le mot de passe</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input 
                            type="password" 
                            id="confirm-password" 
                            class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300"
                            name="confirm_password"
                            placeholder="••••••••"
                            required>
                        <button type="button" id="toggleConfirmPassword" class="absolute right-3 top-3 text-gray-400 hover:text-bleu-canard">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="mb-6">
                    <div class="flex items-center">
                        <input type="checkbox" id="terms" name="terms" class="rounded text-bleu-canard focus:ring-bleu-canard" required>
                        <label for="terms" class="ml-2 text-sm text-gray-600">J'accepte les <a href="#" class="text-bleu-canard hover:text-bleu-canard-fonce hover:underline">Conditions Générales d'Utilisation</a></label>
                    </div>
                </div>

                <button 
                    type="submit"
                    name="submit_inscription"
                    class="btn-hover w-full bg-bleu-canard text-white font-bold py-3 px-4 rounded-lg transition duration-300 hover:bg-bleu-canard-fonce mb-6">
                    S'inscrire
                </button>
                

                <div class="text-center text-gray-600">
                    <p>Déjà un compte? <a href="connexion.php" class="text-bleu-canard hover:text-bleu-canard-fonce font-semibold hover:underline">Se connecter</a></p>
                </div>
                
            </form>
        </div>
        
        <div class="bg-beige-fonce text-gray-600 text-center py-4 text-sm">
            <p>© 2023 firdaws kouskous. Tous droits réservés.</p>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(inputId, toggleButtonId) {
            const passwordInput = document.getElementById(inputId);
            const toggleButton = document.getElementById(toggleButtonId);
            const icon = toggleButton.querySelector('i');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        document.getElementById('togglePassword').addEventListener('click', function() {
            togglePasswordVisibility('password', 'togglePassword');
        });

        document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
            togglePasswordVisibility('confirm-password', 'toggleConfirmPassword');
        });
        
        document.getElementById('inscriptionForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            const termsChecked = document.getElementById('terms').checked;
            const clientErrorContainer = document.getElementById('client-side-errors');
            let clientErrors = [];

            clientErrorContainer.innerHTML = '';
            clientErrorContainer.classList.add('hidden');

            if (password !== confirmPassword) {
                clientErrors.push('Les mots de passe ne correspondent pas.');
            }
            if (!termsChecked) {
                clientErrors.push('Vous devez accepter les Conditions Générales d\'Utilisation.');
            }

            if (clientErrors.length > 0) {
                e.preventDefault(); 
                clientErrors.forEach(errorText => {
                    const errorElement = document.createElement('p');
                    errorElement.textContent = errorText;
                    clientErrorContainer.appendChild(errorElement);
                });
                clientErrorContainer.classList.remove('hidden'); 
            }
        });
    </script>
</body>
</html>