<?php
session_start();

// Vérifier si l'ID du produit à retirer est passé dans l'URL
if (isset($_GET['id'])) {
    $id_produit = $_GET['id'];

    // Si le panier existe et que le produit est dedans, le retirer
    if (isset($_SESSION['panier'][$id_produit])) {
        unset($_SESSION['panier'][$id_produit]);
    }
}

// Rediriger l'utilisateur vers la page du panier
header('Location: panier.php');
exit();

