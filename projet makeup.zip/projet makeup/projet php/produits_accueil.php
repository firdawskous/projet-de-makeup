<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php?error=auth_required");
    exit();
}

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    header("Location: table.php");
    exit();
}

// Calculer le nombre total d'articles dans le panier
$nombre_articles_panier = 0;
if (isset($_SESSION['panier']) && is_array($_SESSION['panier'])) {
    $nombre_articles_panier = array_sum($_SESSION['panier']);
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $stmt = $pdo->query("SELECT id, nom, type, marque, prix, image, disponibilite FROM produit WHERE disponibilite != 'out-of-stock' ORDER BY nom ASC");
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Produits - Élégance Naturelle</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080',
                        'bleu-canard-fonce': '#006666',
                        'beige-fonce': '#E5E5CB',
                        'gold': '#D4AF37',
                    },
                    fontFamily: {
                        'playfair': ['"Playfair Display"', 'serif'],
                        'montserrat': ['Montserrat', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
        }
        
        .product-card {
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
        }
        
        .product-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            border-color: #000080;
        }
        
        .product-image-container {
            height: 280px;
            position: relative;
            overflow: hidden;
        }
        
        .product-image-container img {
            transition: transform 0.5s ease;
        }
        
        .product-card:hover .product-image-container img {
            transform: scale(1.05);
        }
        
        .availability-badge { 
            padding: 0.25rem 0.75rem; 
            border-radius: 9999px; 
            font-size: 0.75rem; 
            font-weight: 600; 
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .nav-link::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: #000080;
            transition: width 0.3s;
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        .price-tag {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: rgba(0, 0, 128, 0.9);
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-weight: 600;
            z-index: 1;
        }
        
        .cart-icon {
            position: absolute;
            bottom: 20px;
            right: 20px;
            background-color: rgba(212, 175, 55, 0.9);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 2;
        }
        
        .product-card:hover .cart-icon {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body class="bg-beige">
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                    <a href="accueil.php" class="text-bleu-canard font-semibold text-xl">firdaws kouskous</a>
                </div>
                
                <div class="hidden md:flex space-x-8">
                    <a href="accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Accueil</a>
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                        <a href="table.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Tableau de bord</a>
                    <?php endif; ?>
                    <a href="produits_accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition font-semibold text-bleu-canard">Produits</a>
                    <a href="#" class="nav-link text-gray-700 hover:text-bleu-canard transition">Collections</a>
                    <a href="contact.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Contact</a>
                </div>
                
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-700 hidden md:block">
                        Bonjour, <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? $_SESSION['user_nom']); ?>!
                    </span>
                    <a href="profil.php" class="text-gray-700 hover:text-bleu-canard" title="Mon Profil">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-sm transition duration-200 flex items-center hidden md:block" title="Déconnexion">
                        <i class="fas fa-sign-out-alt md:mr-2"></i>
                        <span class="hidden md:inline">Déconnexion</span>
                    </a>
                    <a href="panier.php" class="text-gray-700 hover:text-bleu-canard relative ml-2" title="Voir le panier">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($nombre_articles_panier > 0): ?>
                            <span class="absolute -top-2 -right-2 bg-bleu-canard text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"><?php echo $nombre_articles_panier; ?></span>
                        <?php endif; ?>
                    </a>
                    <button class="md:hidden text-gray-700">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-12">
        <h1 class="text-4xl font-bold text-bleu-canard mb-6 text-center font-playfair">Notre Collection Exclusive</h1>
        <p class="text-gray-600 text-center max-w-2xl mx-auto mb-12">Découvrez notre sélection artisanale de produits naturels, conçus avec passion pour apporter élégance et sérénité à votre intérieur.</p>

        <?php if (isset($_SESSION['order_confirmation'])): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg text-center max-w-2xl mx-auto flex items-center justify-center">
                <i class="fas fa-check-circle mr-3"></i>
                <span><?php echo htmlspecialchars($_SESSION['order_confirmation']); ?></span>
            </div>
            <?php unset($_SESSION['order_confirmation']); // On efface le message pour ne pas le réafficher ?>
        <?php endif; ?>

        <?php if (isset($_GET['login']) && $_GET['login'] === 'success_user'): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg text-center max-w-2xl mx-auto">
                Connexion réussie. Bienvenue <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? ''); ?> !
            </div>
        <?php endif; ?>

        <?php if ($stmt->rowCount() > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                <?php while ($produit = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                    <div class="product-card bg-white rounded-lg overflow-hidden transition-all duration-300 relative">
                        <div class="product-image-container relative">
                            <?php if (!empty($produit['image'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($produit['image']); ?>" alt="<?php echo htmlspecialchars($produit['nom']); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <div class="w-full h-full bg-gray-100 flex items-center justify-center">
                                    <i class="fas fa-image fa-3x text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                            <div class="price-tag">
                                <?php echo htmlspecialchars(number_format((float)$produit['prix'], 2, ',', ' ')); ?> MAD
                            </div>
                            <form action="ajouter_panier.php" method="POST">
                                <input type="hidden" name="id_produit" value="<?php echo htmlspecialchars($produit['id']); ?>">
                                <button type="submit" class="cart-icon hover:bg-bleu-canard" title="Ajouter au panier">
                                    <i class="fas fa-shopping-cart"></i>
                                </button>
                            </form>
                        </div>
                        <div class="p-5">
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($produit['nom']); ?></h3>
                                <?php
                                $dispo_text = htmlspecialchars($produit['disponibilite']);
                                $dispo_class = 'bg-gray-200 text-gray-700';
                                if (strtolower($dispo_text) === 'in-stock') {
                                    $dispo_class = 'bg-green-100 text-green-700';
                                } elseif (strtolower($dispo_text) === 'pre-order') {
                                    $dispo_class = 'bg-blue-100 text-blue-700';
                                }
                                ?>
                                <span class="availability-badge <?php echo $dispo_class; ?>">
                                    <?php echo $dispo_text === 'in-stock' ? 'En stock' : ($dispo_text === 'pre-order' ? 'Pré-commande' : $dispo_text); ?>
                                </span>
                            </div>
                            <p class="text-sm text-gray-600 mb-1"><span class="font-medium">Marque:</span> <?php echo htmlspecialchars($produit['marque']); ?></p>
                            <p class="text-sm text-gray-600 mb-4"><span class="font-medium">Type:</span> <?php echo htmlspecialchars($produit['type']); ?></p>
                            
                            <button class="w-full bg-bleu-canard hover:bg-bleu-canard-fonce text-white font-semibold py-2 px-4 rounded transition duration-300 flex items-center justify-center">
                                <i class="fas fa-eye mr-2"></i> Voir les détails
                            </button>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-box-open text-4xl text-gray-400 mb-4"></i>
                <p class="text-xl text-gray-600">Aucun produit disponible pour le moment.</p>
                <p class="text-gray-500 mt-2">Revenez bientôt pour découvrir nos nouvelles collections.</p>
            </div>
        <?php endif; ?>
    </div>

    <footer class="bg-gray-900 text-white pt-12 pb-6 mt-16">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                        <span class="text-xl font-semibold">firdaws kouskous</span>
                    </div>
                    <p class="text-gray-400 mb-4">Des produits artisanaux qui marient élégance et naturel pour votre intérieur.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-gold transition"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-gray-400 hover:text-gold transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-gray-400 hover:text-gold transition"><i class="fab fa-pinterest-p"></i></a>
                        <a href="#" class="text-gray-400 hover:text-gold transition"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-gold">Navigation</h3>
                    <ul class="space-y-2">
                        <li><a href="accueil.php" class="text-gray-400 hover:text-beige transition">Accueil</a></li>
                        <li><a href="produits_accueil.php" class="text-gray-400 hover:text-beige transition">Boutique</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Collections</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">À propos</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Contact</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-gold">Informations</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Livraison</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Retours</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Politique de confidentialité</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Conditions générales</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">FAQ</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-gold">Contact</h3>
                    <ul class="space-y-2">
                        <li class="flex items-center text-gray-400"><i class="fas fa-map-marker-alt mr-2 text-gold"></i> 71 ait khassa 02 hamria khenifra</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-phone-alt mr-2 text-gold"></i> +212 682114015</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-envelope mr-2 text-gold"></i> kouskousfirdaws@gmail.com</li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 pt-6 text-center">
                <p class="text-gray-400 text-sm">&copy; <?php echo date("Y"); ?> firdaws kouskous. Tous droits réservés.</p>
            </div>
        </div>
    </footer>
</body>
</html>