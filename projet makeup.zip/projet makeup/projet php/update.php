<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

$message = '';
$produit = null; 
$upload_dir = 'uploads/'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $nom = trim(filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING));
    $type = trim(filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING));
    $code = trim(filter_input(INPUT_POST, 'code', FILTER_SANITIZE_STRING));
    $marque = trim(filter_input(INPUT_POST, 'marque', FILTER_SANITIZE_STRING));
    $prix = filter_input(INPUT_POST, 'prix', FILTER_VALIDATE_FLOAT);
    $disponibilite = trim(filter_input(INPUT_POST, 'disponibilite', FILTER_SANITIZE_STRING));
        $current_image = trim(filter_input(INPUT_POST, 'current_image', FILTER_SANITIZE_STRING));
    $image_to_update = $current_image; 

    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $tmp_name = $_FILES['image']['tmp_name'];
        $original_filename = basename($_FILES['image']['name']);
        $safe_filename = preg_replace("/[^A-Za-z0-9._-]/", "", $original_filename);
        $new_image_filename = uniqid() . "_" . $safe_filename;
        $target_path = $upload_dir . $new_image_filename;

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($tmp_name);

        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($tmp_name, $target_path)) {
                $image_to_update = $new_image_filename;
                if (!empty($current_image) && $current_image !== $new_image_filename && file_exists($upload_dir . $current_image)) {
                    unlink($upload_dir . $current_image);
                }
            } else {
                $message = "Erreur lors du déplacement de la nouvelle image.";
            }
        } else {
            $message = "Type de fichier non autorisé pour la nouvelle image. Uniquement JPG, PNG, GIF.";
        }
    } elseif (isset($_FILES['image']) && $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
        $message = "Erreur de téléversement de la nouvelle image : " . $_FILES['image']['error'];
    }
    if (empty($message) && $id && !empty($nom) && !empty($type) && !empty($code) && !empty($marque) && $prix !== false && !empty($disponibilite)) {
        try {
            $sql = "UPDATE produit SET nom = :nom, type = :type, code = :code, marque = :marque, prix = :prix, disponibilite = :disponibilite, image = :image WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':type', $type);
            $stmt->bindParam(':code', $code);
            $stmt->bindParam(':marque', $marque);
            $stmt->bindParam(':prix', $prix);
            $stmt->bindParam(':disponibilite', $disponibilite);
            $stmt->bindParam(':image', $image_to_update);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);

            if ($stmt->execute()) {
                header("Location: table.php?status=updated"); 
                exit;
            } else {
                $message = "Erreur lors de la mise à jour du produit.";
                $_POST['image'] = $image_to_update; 
                $produit = $_POST; 
            }
        } catch (PDOException $e) {
            $message = "Erreur de base de données : " . $e->getMessage();
            $_POST['image'] = $image_to_update;
            $produit = $_POST;
        }
    } else {
        if (empty($message)) $message = "Tous les champs obligatoires sont requis et le prix doit être un nombre valide.";
        $_POST['image'] = $image_to_update; 
        $produit = $_POST;
        if ($id) {
            $produit['id'] = $id;
        } else {
            $id_from_get = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            if ($id_from_get) {
                 $produit['id'] = $id_from_get;
            } else {
                 $message .= " L'ID du produit est manquant.";
            }
        }
    }
} else {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM produit WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $produit = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$produit) {
            $message = "Produit non trouvé.";
            
        }
    } else {
        $message = "Aucun ID de produit fourni pour la modification.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le Produit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: {
                            '50': '#f0f4ff',
                            '100': '#dde6ff',
                            '200': '#c2d3ff',
                            '300': '#9cb6ff',
                            '400': '#758dff',
                            '500': '#4f61ff',
                            '600': '#2f3af5',
                            '700': '#222ad8',
                            '800': '#2128ae',
                            '900': '#212989',
                            '950': '#131652',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
    </style>
</head>
<body class="bg-beige">
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-edit mr-3 text-navy-600"></i>
                Modifier le Produit
            </h1>
            <a href="table.php" class="bg-navy-700 hover:bg-navy-800 text-white px-4 py-2 rounded-lg transition duration-200 flex items-center">
                <i class="fas fa-arrow-left mr-2"></i> Retour à la liste
            </a>
        </div>

        <?php if (!empty($message)): ?>
            <div class="mb-4 p-4 <?php echo (strpos(strtolower($message), 'erreur') !== false || strpos(strtolower($message), 'requis') !== false || strpos(strtolower($message), 'manquant') !== false || strpos(strtolower($message), 'non trouvé') !== false) ? 'bg-red-100 border-red-400 text-red-700' : 'bg-green-100 border-green-400 text-green-700'; ?> border rounded">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <?php if ($produit && isset($produit['id'])):  ?>
        <div class="bg-white p-8 rounded-lg custom-shadow max-w-2xl mx-auto">
            <form action="update.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($produit['id']); ?>">

                <div class="mb-4">
                    <label for="nom" class="block text-sm font-medium text-gray-700 mb-1">Nom du produit</label>
                    <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($produit['nom'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                    <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($produit['image'] ?? ''); ?>">
                </div>

                <div class="mb-4">
                    <label for="type" class="block text-sm font-medium text-gray-700 mb-1">Type</label>
                    <input type="text" name="type" id="type" value="<?php echo htmlspecialchars($produit['type'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="code" class="block text-sm font-medium text-gray-700 mb-1">Code</label>
                    <input type="text" name="code" id="code" value="<?php echo htmlspecialchars($produit['code'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="marque" class="block text-sm font-medium text-gray-700 mb-1">Marque</label>
                    <input type="text" name="marque" id="marque" value="<?php echo htmlspecialchars($produit['marque'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                </div>

                <div class="mb-4">
                    <label for="prix" class="block text-sm font-medium text-gray-700 mb-1">Prix (MAD)</label>
                    <input type="number" step="0.01" name="prix" id="prix" value="<?php echo htmlspecialchars($produit['prix'] ?? ''); ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                </div>

                <div class="mb-6">
                    <label for="disponibilite" class="block text-sm font-medium text-gray-700 mb-1">Disponibilité</label>
                    <select name="disponibilite" id="disponibilite" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-navy-500 focus:border-navy-500 sm:text-sm">
                        <option value="in-stock" <?php echo (isset($produit['disponibilite']) && strtolower($produit['disponibilite']) == 'in-stock') ? 'selected' : ''; ?>>In-Stock</option>
                        <option value="out-of-stock" <?php echo (isset($produit['disponibilite']) && strtolower($produit['disponibilite']) == 'out-of-stock') ? 'selected' : ''; ?>>Out-of-Stock</option>
                        <option value="pre-order" <?php echo (isset($produit['disponibilite']) && strtolower($produit['disponibilite']) == 'pre-order') ? 'selected' : ''; ?>>Pré-commande</option>
                    </select>
                </div>
                <div class="mb-6">
                    <label for="image" class="block text-sm font-medium text-gray-700 mb-1">Image du produit (optionnel)</label>
                    <?php if (!empty($produit['image']) && file_exists($upload_dir . $produit['image'])): ?>
                        <div class="mb-2">
                            <img src="<?php echo $upload_dir . htmlspecialchars($produit['image']); ?>" alt="Image actuelle" class="h-24 w-auto rounded shadow-md object-cover">
                            <p class="text-xs text-gray-500 mt-1">Actuelle : <?php echo htmlspecialchars($produit['image']); ?></p>
                        </div>
                    <?php elseif (!empty($produit['image'])): ?>
                        <p class="text-xs text-red-500 mb-1">Fichier image actuel non trouvé : <?php echo htmlspecialchars($produit['image']); ?></p>
                    <?php endif; ?>
                    <input type="file" name="image" id="image" accept="image/png, image/jpeg, image/gif" class="mt-1 block w-full text-sm text-gray-500
                        file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold
                        file:bg-navy-50 file:text-navy-700 hover:file:bg-navy-100 cursor-pointer border border-gray-300 rounded-md px-3 py-2">
                    <p class="text-xs text-gray-500 mt-1">Laissez vide pour conserver l'image actuelle. Téléchargez un nouveau fichier pour la remplacer.</p>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="bg-navy-700 hover:bg-navy-800 text-white font-semibold px-6 py-2 rounded-lg transition duration-200 flex items-center">
                        <i class="fas fa-save mr-2"></i> Enregistrer les modifications
                    </button>
                </div>
            </form>
        </div>
        <?php elseif (empty($message) && !$produit):  ?>
            <div class="bg-white p-8 rounded-lg custom-shadow max-w-2xl mx-auto text-center">
                <p class="text-gray-600">Veuillez fournir un ID de produit pour la modification via l'URL (ex: update.php?id=1).</p>
                 <a href="table.php" class="mt-4 inline-block bg-navy-600 hover:bg-navy-700 text-white px-4 py-2 rounded-lg transition duration-200">
                    Retour à la liste
                </a>
            </div>
        <?php endif; ?>
    </div>
    
</body>
</html>

