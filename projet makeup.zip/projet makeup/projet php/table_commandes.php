<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: connexion.php?error=auth_required");
    exit();
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=organisation_produit;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données. Veuillez réessayer plus tard.");
}

// Jointure pour récupérer le nom du client
$stmt = $pdo->query("
    SELECT c.id_commande, c.date_commande, c.total, c.statut, cl.nom, cl.prenom 
    FROM commandes c 
    JOIN client cl ON c.id_client = cl.id 
    ORDER BY c.date_commande DESC
"); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau des Commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        navy: { '50': '#f0f4ff', '100': '#dde6ff', '200': '#c2d3ff', '300': '#9cb6ff', '400': '#758dff', '500': '#4f61ff', '600': '#2f3af5', '700': '#222ad8', '800': '#2128ae', '900': '#212989', '950': '#131652' }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-shadow { box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); }
        .status-badge { padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    </style>
</head>
<body class="bg-beige">
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-8">
                    <a href="table.php" class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-navy-700 flex items-center justify-center text-white font-bold text-xl mr-2">A</div>
                        <span class="text-navy-800 font-semibold text-xl">Admin</span>
                    </a>
                    <div class="hidden md:flex space-x-6">
                        <a href="table.php" class="text-gray-600 hover:text-navy-700 transition">Produits</a>
                        <a href="table_client.php" class="text-gray-600 hover:text-navy-700 transition">Clients</a>
                        <a href="table_commandes.php" class="text-navy-700 font-semibold border-b-2 border-navy-700 pb-1">Commandes</a>
                        <a href="accueil.php" class="text-gray-600 hover:text-navy-700 transition" target="_blank" title="Ouvrir la page d'accueil dans un nouvel onglet">
                            Voir le site <i class="fas fa-external-link-alt text-xs ml-1"></i>
                        </a>
                    </div>
                </div>
                
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600 hidden sm:block">
                        Bienvenue, <?php echo htmlspecialchars($_SESSION['user_prenom'] ?? $_SESSION['user_nom']); ?>!
                    </span>
                    <a href="profil.php" class="text-gray-600 hover:text-navy-700" title="Mon Profil">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-sm transition duration-200 flex items-center" title="Déconnexion">
                        <i class="fas fa-sign-out-alt md:mr-2"></i>
                        <span class="hidden md:inline">Déconnexion</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-receipt mr-3 text-navy-600"></i>
                Tableau des Commandes
            </h1>
        </div>

        <div class="bg-white rounded-lg custom-shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-navy-800 bg-navy-700">
                <h2 class="text-lg font-semibold text-white">
                    <i class="fas fa-list-ul mr-2 text-navy-100"></i> Liste des commandes
                </h2>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-navy-100">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">N° Commande</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">Client</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-navy-700 uppercase tracking-wider">Date</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-navy-700 uppercase tracking-wider">Total</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-navy-700 uppercase tracking-wider">Statut</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-navy-700 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php while ($commande = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr class="hover:bg-navy-50 transition duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">#<?php echo htmlspecialchars($commande['id_commande']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($commande['prenom'] . ' ' . $commande['nom']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($commande['date_commande']))); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right">
                                <div class="text-sm font-semibold text-gray-800"><?php echo htmlspecialchars(number_format($commande['total'], 2, ',', ' ')); ?> MAD</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="status-badge bg-yellow-100 text-yellow-800"><?php echo htmlspecialchars($commande['statut']); ?></span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                <a href="table_commande_produits.php?id=<?php echo $commande['id_commande']; ?>" class="text-navy-600 hover:text-navy-900" title="Voir les détails">
                                    <i class="fas fa-eye"></i> Voir
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($stmt->rowCount() === 0): ?>
                            <tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">Aucune commande trouvée.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
