<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php?error=auth_required");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_nom = $_SESSION['user_nom'] ?? 'N/A';
$user_prenom = $_SESSION['user_prenom'] ?? 'N/A';
$user_email = $_SESSION['user_email'] ?? 'N/A';
$user_role = $_SESSION['user_role'] ?? 'N/A';

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil - firdaws kouskous</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
navy: {
                            '50': '#f0f4ff',
                            '100': '#dde6ff',
                            '200': '#c2d3ff',
                            '300': '#9cb6ff',
                            '400': '#758dff',
                            '500': '#4f61ff',
                            '600': '#2f3af5',
                            '700': '#222ad8',
                            '800': '#2128ae',
                            '900': '#212989',
                            '950': '#131652',
                        }                    }
                }
            }
        }
    </script>
</head>
<body class="bg-beige min-h-screen">
    <style>
        .custom-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
    </style>
    <nav class="bg-white shadow-md py-4">
        <div class="container mx-auto px-6 flex justify-between items-center">
            <a href="<?php echo ($user_role === 'admin') ? 'table.php' : 'produits_accueil.php'; ?>" class="text-2xl font-bold text-navy-700">
                 <?php if ($user_role === 'admin'){echo "(Admin)";}else{echo "(Utilisateur)";}  ?>
            </a>
            <div class="flex items-center space-x-4">
                 <a href="<?php echo ($user_role === 'admin') ? 'table.php' : 'produits_accueil.php'; ?>" class="text-navy-600 hover:text-navy-800">
                    <i class="fas fa-arrow-left mr-1"></i> Retour
                </a>
                <a href="logout.php" class="bg-navy-600 hover:bg-navy-700 text-white px-4 py-2 rounded-lg text-sm transition">
                    <i class="fas fa-sign-out-alt mr-2"></i>Déconnexion
                </a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-12">
        <div class="bg-white rounded-lg custom-shadow overflow-hidden max-w-2xl mx-auto">
            <div class="bg-navy-700 px-6 py-4">
                <h2 class="text-xl font-semibold text-white flex items-center">
                    <i class="fas fa-user-circle mr-3"></i> Mon Profil
                </h2>

            </div>

            <div class="p-6 md:p-8">
                <div class="text-center mb-6">
                    <i class="fas fa-user-shield fa-3x text-navy-500 mb-3"></i>
                    <h3 class="text-2xl font-semibold text-navy-700">
                        Bienvenue, <?php echo htmlspecialchars($user_prenom); ?> !
                    </h3>
                </div>
                 <div class="space-y-4">
                    <div class="p-4 bg-navy-50 rounded-lg border border-navy-100">
                        <p class="text-sm font-medium text-navy-600">Nom complet</p>
                        <p class="text-lg text-navy-900"><?php echo htmlspecialchars($user_prenom) . ' ' . htmlspecialchars($user_nom); ?></p>
                    </div>
                    <div class="p-4 bg-navy-50 rounded-lg border border-navy-100">
                        <p class="text-sm font-medium text-navy-600">Adresse e-mail</p>
                        <p class="text-lg text-navy-900"><?php echo htmlspecialchars($user_email); ?></p>
                    </div>

                    <div class="p-4 bg-navy-50 rounded-lg border border-navy-100">
                        <p class="text-sm font-medium text-navy-600">Rôle</p>
                        <p class="text-lg text-navy-900 capitalize"><?php echo htmlspecialchars($user_role); ?></p>
                    </div>
                </div>
                 <div class="mt-8 pt-6 border-t border-gray-200 text-center">
                    <a href="#" class="bg-navy-600 hover:bg-navy-700 text-white font-semibold py-2 px-6 rounded-lg transition duration-300 inline-flex items-center">
                        <i class="fas fa-edit mr-2"></i> Modifier mes informations
                    </a>
                </div>
            
            </div>
        </div>
    </div>

    <footer class="bg-navy-800 text-beige-fonce text-center py-6 mt-12">
        <p>&copy; <?php echo date("Y"); ?> firdaw kouskous. Tous droits réservés.</p>
    </footer>
</body>
</html>

