<?php
session_start(); 

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactez-nous | firdaws kouskous</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        beige: '#F5F5DC',
                        'bleu-canard': '#000080', 
                        'bleu-canard-fonce': '#006666',
                        'beige-fonce': '#E5E5CB',
                    }
                }
            }
        }
    </script>
    <style>
        
        .nav-link::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: #000080;
            transition: width 0.3s;
        }
        
        .nav-link:hover::after, .nav-link-active::after {
            width: 100%;
        }

        .mobile-menu {
            transition: max-height 0.3s ease-out;
            max-height: 0;
            overflow: hidden;
        }
        .mobile-menu.open { max-height: 1000px; }
        body.menu-open { overflow: hidden; }
    </style>
    <style>
        
        .form-container {
            background: linear-gradient(135deg, rgba(245, 245, 220, 0.2) 0%, rgba(0, 0, 128, 0.1) 100%);
        }
        
        .input-focus:focus {
            border-color: #000080;
            box-shadow: 0 0 0 3px rgba(0, 0, 128, 0.2);
        }
        
        .btn-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 128, 0.2);
        }
    </style>
</head>
<body class="bg-beige font-sans">

    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-4 sm:px-6 py-3">
            <div class="flex items-center justify-between">

                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                    <span class="text-bleu-canard font-semibold text-xl">firdaws kouskous</span>
                </div>
                
                <div class="hidden md:flex items-center space-x-6 lg:space-x-8">
                    <a href="accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Accueil</a>
                    <a href="produits_accueil.php" class="nav-link text-gray-700 hover:text-bleu-canard transition">Produits</a>
                    <a href="accueil.php#collection" class="nav-link text-gray-700 hover:text-bleu-canard transition">Collections</a>
                    <a href="accueil.php#apropos" class="nav-link text-gray-700 hover:text-bleu-canard transition">À propos</a>
                    <a href="contact.php" class="nav-link nav-link-active text-bleu-canard font-semibold transition">Contact</a>
                </div>

                <div class="flex items-center space-x-4">
                    <button class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard">
                        <i class="fas fa-search"></i>
                    </button>
                    <a href="connexion.php" class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard">
                        <i class="fas fa-user"></i>
                    </a>
                    <button class="hidden sm:inline-block text-gray-700 hover:text-bleu-canard relative">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="absolute -top-2 -right-2 bg-bleu-canard text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
                    </button>
                    <button id="mobile-menu-button" class="md:hidden text-gray-700 focus:outline-none">
                        <i id="mobile-menu-icon" class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <div id="mobile-menu" class="mobile-menu md:hidden bg-white border-t border-gray-200">
            <div class="container mx-auto px-4 py-2">
                <a href="accueil.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Accueil</a>
                <a href="produits_accueil.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Produits</a>
                <a href="accueil.php#collection" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">Collections</a>
                <a href="accueil.php#apropos" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition">À propos</a>
                <a href="contact.php" class="block py-3 px-4 text-gray-700 bg-beige-fonce rounded transition font-semibold">Contact</a>
                <div class="border-t border-gray-200 mt-2 pt-2">
                    <a href="connexion.php" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition"><i class="fas fa-user mr-2"></i>Connexion</a>
                    <a href="#" class="block py-3 px-4 text-gray-700 hover:bg-beige-fonce rounded transition"><i class="fas fa-shopping-cart mr-2"></i>Panier</a>
                </div>
            </div>
        </div>
    </nav>

    <main class="py-12 md:py-16">
        <div class="container mx-auto px-4">
            <div class="form-container w-full max-w-lg mx-auto rounded-2xl overflow-hidden shadow-xl bg-white">

                <div class="bg-bleu-canard text-white p-8 text-center">
                    <div class="w-16 h-16 rounded-full bg-white flex items-center justify-center text-bleu-canard font-bold text-2xl mx-auto mb-4">
                        <i class="fas fa-paper-plane"></i>
                    </div>
                    <h1 class="text-2xl font-bold">Contactez-nous</h1>
                    <p class="text-beige mt-2">Une question ou une suggestion ? N'hésitez pas à nous écrire.</p>
                </div>

                <div class="p-6 md:p-8">
                    <?php
                    if (isset($_SESSION['contact_status'])) {
                        $status = $_SESSION['contact_status'];
                        $bgColor = $status['success'] ? 'bg-green-100 border-green-400 text-green-700' : 'bg-red-100 border-red-400 text-red-700';
                        echo '<div class="mb-4 p-3 ' . $bgColor . ' rounded-lg text-sm">';
                        echo '<p>' . htmlspecialchars($status['message']) . '</p>';
                        echo '</div>';
                        unset($_SESSION['contact_status']); 
                    }
                    ?>
                    <form action="contact_process.php" method="POST">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <label for="lastname" class="block text-gray-700 mb-2">Nom</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-user text-gray-400"></i>
                                    </div>
                                    <input type="text" id="lastname" name="nom" class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300" required>
                                </div>
                            </div>
                            <div>
                                <label for="firstname" class="block text-gray-700 mb-2">Prénom</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-user text-gray-400"></i>
                                    </div>
                                    <input type="text" id="firstname" name="prenom" class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300" required>
                                </div>
                            </div>
                        </div>

                        <div class="mb-6">
                            <label for="email" class="block text-gray-700 mb-2">Adresse email</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-envelope text-gray-400"></i>
                                </div>
                                <input type="email" id="email" name="email" class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300" required>
                            </div>
                        </div>
                        
                        <div class="mb-6">
                            <label for="subject" class="block text-gray-700 mb-2">Sujet</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-pencil-alt text-gray-400"></i>
                                </div>
                                <input type="text" id="subject" name="sujet" class="input-focus w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none transition duration-300" required>
                            </div>
                        </div>

                        <div class="mb-6">
                            <label for="message" class="block text-gray-700 mb-2">Votre message</label>
                            <textarea id="message" name="message" rows="5" class="input-focus w-full px-4 py-3 border rounded-lg focus:outline-none transition duration-300" required></textarea>
                        </div>

                        <button type="submit" name="submit_contact" class="btn-hover w-full bg-bleu-canard text-white font-bold py-3 px-4 rounded-lg transition duration-300 hover:bg-bleu-canard-fonce mb-6">
                            <i class="fas fa-paper-plane mr-2"></i> Envoyer le message
                        </button>
                    </form>
                </div>

                <div class="bg-beige-fonce text-gray-600 text-center py-4 text-sm">
                    <p>© <?php echo date('Y'); ?> firdaws kouskous. Tous droits réservés.</p>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-gray-900 text-white pt-12 pb-6">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 rounded-full bg-bleu-canard flex items-center justify-center text-white font-bold text-xl mr-2">FK</div>
                        <span class="text-xl font-semibold">firdaws kouskous</span>
                    </div>
                    <p class="text-gray-400 mb-4">Des produits artisanaux qui marient élégance et naturel pour votre intérieur.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-beige transition"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-gray-400 hover:text-beige transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-gray-400 hover:text-beige transition"><i class="fab fa-pinterest-p"></i></a>
                        <a href="#" class="text-gray-400 hover:text-beige transition"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Navigation</h3>
                    <ul class="space-y-2">
                        <li><a href="accueil.php" class="text-gray-400 hover:text-beige transition">Accueil</a></li>
                        <li><a href="produits_accueil.php" class="text-gray-400 hover:text-beige transition">Produits</a></li>
                        <li><a href="accueil.php#collection" class="text-gray-400 hover:text-beige transition">Collections</a></li>
                        <li><a href="contact.php" class="text-gray-400 hover:text-beige transition">Contact</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Informations</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Livraison</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Retours</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Politique de confidentialité</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">Conditions générales</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-beige transition">FAQ</a></li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-beige">Contact</h3>
                    <ul class="space-y-2">
                        <li class="flex items-center text-gray-400"><i class="fas fa-map-marker-alt mr-2 text-beige"></i> 71 ait khassa 02 hamria khenifra</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-phone-alt mr-2 text-beige"></i> +212 682114015</li>
                        <li class="flex items-center text-gray-400"><i class="fas fa-envelope mr-2 text-beige"></i> kouskousfirdaws@gmail.com</li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-400 text-sm mb-4 md:mb-0">© <?php echo date('Y'); ?> firdaws kouskous. Tous droits réservés.</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileMenuIcon = document.getElementById('mobile-menu-icon');

            mobileMenuButton.addEventListener('click', function(e) {
                e.stopPropagation();
                
                mobileMenu.classList.toggle('open');
                document.body.classList.toggle('menu-open');
                
                mobileMenuIcon.classList.toggle('fa-bars');
                mobileMenuIcon.classList.toggle('fa-times');
            });

            document.querySelectorAll('#mobile-menu a').forEach(link => {
                link.addEventListener('click', () => {
                    if (mobileMenu.classList.contains('open')) {
                        mobileMenu.classList.remove('open');
                        mobileMenuIcon.classList.remove('fa-times');
                        mobileMenuIcon.classList.add('fa-bars');
                        document.body.classList.remove('menu-open');
                    }
                });
            });
        });
    </script>
</body>
</html>